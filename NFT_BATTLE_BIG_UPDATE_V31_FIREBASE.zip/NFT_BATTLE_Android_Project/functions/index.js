const { onSchedule } = require('firebase-functions/v2/scheduler');
const { setGlobalOptions } = require('firebase-functions/v2');
const admin = require('firebase-admin');

admin.initializeApp();
setGlobalOptions({ region: 'europe-west2', maxInstances: 1 });
const db = admin.firestore();
const MAX_STARS = 3_000_000_000_000;
const MAX_INVENTORY_VALUE = 1_000_000_000_000_000_000;
const BOT_COUNT = 40;
const namesA = ['Silent','Neon','Frost','Shadow','Lucky','Crystal','Nova','Pixel','Turbo','Cosmic','Velvet','Dark','Rapid','Solar','Mystic','Zero','Royal','Ghost','Blue','Wild'];
const namesB = ['Fox','Wolf','Star','Raven','Tiger','Comet','Knight','Byte','Dragon','Cat','Orbit','Bear','Spark','Phantom','Ace','Storm','Pearl','Viper','Flame','Echo'];
const avatars = ['🦊','🐺','🐯','🦉','🐼','🐸','🐲','🐱','🦁','🐻','🐨','🦄','🐙','🦋','🐧','🐢','🦅','🐬','🦝','🐹','🐮','🐵','🦖','🐳','🐝','🦩','🦜','🦔','🐺','🐉','🦈','🐰','🐻‍❄️','🦚','🦋','🐌','🦦','🐾','🐣','🦕'];
const pools = [
  [{id:'heart',name:'Сердце',icon:'❤️',price:15,rarity:'Обычный'},{id:'rose',name:'Роза',icon:'🌹',price:25,rarity:'Обычный'},{id:'flowers',name:'Цветы',icon:'💐',price:50,rarity:'Обычный'},{id:'rocket',name:'Ракета',icon:'🚀',price:50,rarity:'Обычный'},{id:'diamond',name:'Алмаз',icon:'💎',price:100,rarity:'Необычный'},{id:'mixedPop',name:'Смешанный поп',icon:'🍬',price:325,rarity:'Редкий'}],
  [{id:'toyBear',name:'Игрушечный медведь',icon:'🧸',price:2500,rarity:'Редкий'},{id:'vinylPlayer',name:'Виниловый проигрыватель',icon:'📀',price:5825,rarity:'Редкий'},{id:'rocket',name:'Ракета',icon:'🚀',price:50,rarity:'Обычный'},{id:'goldBear',name:'Золотой медведь',icon:'🐻',price:25000,rarity:'Эпический'}],
  [{id:'turtlePepeMike',name:'Плюшевый пепе (Майк)',icon:'🐸',price:8825756,rarity:'Эпический'},{id:'turtlePepeDon',name:'Плюшевый пепе (Донателло)',icon:'🐸',price:11937224,rarity:'Эпический'},{id:'turtlePepeRaph',name:'Плюшевый пепе (Рафаэль)',icon:'🐸',price:13537250,rarity:'Эпический'}],
  [{id:'spiderButterfly',name:'Бабочка',icon:'🦋',price:14904562090,rarity:'Эпический'},{id:'spiderWatch',name:'Швейцарские часы',icon:'⌚',price:178506413225,rarity:'Секретный'}]
];
function randomInt(max) { return Math.floor(Math.random() * max); }
function freshBot(i) {
  const nickname = `${pick(namesA)}${pick(namesB)}${10 + randomInt(990)}`;
  return {
    ownerUid: `bot_${String(i + 1).padStart(3, '0')}`,
    playerId: `BOT-${String(i + 1).padStart(3, '0')}`,
    playerIdKey: `BOT-${String(i + 1).padStart(3, '0')}`,
    nickname,
    avatar: avatars[i % avatars.length],
    isBot: true,
    isGuest: false,
    stars: 100,
    inventoryStars: 0,
    itemsCount: 0,
    inventoryPreview: [],
    botInventoryValue: 0,
    botLastCase: 'Бесплатный кейс',
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  };
}
exports.evolveBotAccounts = onSchedule({ schedule: 'every 5 minutes', timeZone: 'Etc/UTC' }, async () => {
  const writes = [];
  const inventoryWrites = [];
  for (let i = 0; i < BOT_COUNT; i++) {
    const id = `bot_${String(i + 1).padStart(3, '0')}`;
    const ref = db.collection('players').doc(id);
    const snap = await ref.get();
    const bot = snap.exists ? (snap.data() || {}) : freshBot(i);
    let stars = Math.max(0, Math.min(MAX_STARS, Number(bot.stars) || 100));
    let value = Math.max(0, Math.min(MAX_INVENTORY_VALUE, Number(bot.inventoryStars) || 0));
    let items = Array.isArray(bot.inventoryPreview) ? bot.inventoryPreview.slice(0, 40) : [];
    // Simulated in-game activity: bots earn small rewards and open only their own virtual cases.
    const itemCount = Math.max(0, Number(bot.itemsCount) || 0);
    // Deterministic offline progression: fixed periodic rewards, not paid or chance-based openings.
    stars = Math.min(MAX_STARS, stars + 20 + ((i * 37 + itemCount * 19) % 981));
    const poolIndex = (i + itemCount) % pools.length;
    const pool = pools[poolIndex];
    const gift = pool[(i + itemCount) % pool.length];
    value = Math.min(MAX_INVENTORY_VALUE, value + gift.price);
    items.unshift({ id: gift.id, name: gift.name, icon: gift.icon, price: gift.price, rarity: gift.rarity, unique: false });
    const nextItemCount = itemCount + 1;
    items = items.slice(0, 40);
    const base = snap.exists ? {} : freshBot(i);
    inventoryWrites.push(db.collection('publicInventories').doc(id).collection('items').doc(String(nextItemCount).padStart(12, '0')).set({
      id: gift.id, name: gift.name, icon: gift.icon, price: gift.price, rarity: gift.rarity, unique: false, updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }));
    writes.push(ref.set({
      ...base,
      ownerUid: id,
      playerId: `BOT-${String(i + 1).padStart(3, '0')}`,
      playerIdKey: `BOT-${String(i + 1).padStart(3, '0')}`,
      isBot: true,
      isGuest: false,
      stars,
      inventoryStars: value,
      itemsCount: nextItemCount,
      inventoryPreview: items,
      botRewardSource: 'Периодическая игровая награда',
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true }));
  }
  await Promise.all([...writes, ...inventoryWrites]);
});
