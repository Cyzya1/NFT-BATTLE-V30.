const { onSchedule } = require('firebase-functions/v2/scheduler');
const { setGlobalOptions } = require('firebase-functions/v2');
const admin = require('firebase-admin');

admin.initializeApp();
setGlobalOptions({ region: 'europe-west2', maxInstances: 1 });
const db = admin.firestore();
const MAX_STARS = 3_000_000_000_000;
const MAX_INVENTORY_VALUE = 1_000_000_000_000_000_000;
const BOT_COUNT = 40;
const namesA = ['Silent','Neon','Frost','Shadow','Lucky','Crystal','Nova','Pixel','Turbo','Cosmic','Velvet','Dark','Rapid','Solar','Mystic','Zero','Royal','Ghost','Blue','Wild'];
const namesB = ['Fox','Wolf','Star','Raven','Tiger','Comet','Knight','Byte','Dragon','Cat','Orbit','Bear','Spark','Phantom','Ace','Storm','Pearl','Viper','Flame','Echo'];
const avatars = ['🦊','🐺','🐯','🦉','🐼','🐸','🐲','🐱','🦁','🐻','🐨','🦄','🐙','🦋','🐧','🐢','🦅','🐬','🦝','🐹','🐮','🐵','🦖','🐳','🐝','🦩','🦜','🦔','🐺','🐉','🦈','🐰','🐻‍❄️','🦚','🦋','🐌','🦦','🐾','🐣','🦕'];
const pools = [
  [{id:'heart',name:'Сердце',icon:'❤️',price:15,rarity:'Обычный'},{id:'rose',name:'Роза',icon:'🌹',price:25,rarity:'Обычный'},{id:'flowers',name:'Цветы',icon:'💐',price:50,rarity:'Обычный'},{id:'rocket',name:'Ракета',icon:'🚀',price:50,rarity:'Обычный'},{id:'diamond',name:'Алмаз',icon:'💎',price:100,rarity:'Необычный'},{id:'mixedPop',name:'Смешанный поп',icon:'🍬',price:325,rarity:'Редкий'}],
  [{id:'toyBear',name:'Игрушечный медведь',icon:'🧸',price:2500,rarity:'Редкий'},{id:'vinylPlayer',name:'Виниловый проигрыватель',icon:'📀',price:5825,rarity:'Редкий'},{id:'rocket',name:'Ракета',icon:'🚀',price:50,rarity:'Обычный'},{id:'goldBear',name:'Золотой медведь',icon:'🐻',price:25000,rarity:'Эпический'}],
  [{id:'turtlePepeMike',name:'Плюшевый пепе (Майк)',icon:'🐸',price:8825756,rarity:'Эпический'},{id:'turtlePepeDon',name:'Плюшевый пепе (Донателло)',icon:'🐸',price:11937224,rarity:'Эпический'},{id:'turtlePepeRaph',name:'Плюшевый пепе (Рафаэль)',icon:'🐸',price:13537250,rarity:'Эпический'}],
  [{id:'spiderButterfly',name:'Бабочка',icon:'🦋',price:14904562090,rarity:'Эпический'},{id:'spiderWatch',name:'Швейцарские часы',icon:'⌚',price:178506413225,rarity:'Секретный'}]
];
function randomInt(max) { return Math.floor(Math.random() * max); }
function freshBot(i) {
  const nickname = `${pick(namesA)}${pick(namesB)}${10 + randomInt(990)}`;
  return {
    ownerUid: `bot_${String(i + 1).padStart(3, '0')}`,
    playerId: `BOT-${String(i + 1).padStart(3, '0')}`,
    playerIdKey: `BOT-${String(i + 1).padStart(3, '0')}`,
    nickname,
    avatar: avatars[i % avatars.length],
    isBot: true,
    isGuest: false,
    stars: 100,
    inventoryStars: 0,
    itemsCount: 0,
    inventoryPreview: [],
    botInventoryValue: 0,
    botLastCase: 'Бесплатный кейс',
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  };
}
exports.evolveBotAccounts = onSchedule({ schedule: 'every 5 minutes', timeZone: 'Etc/UTC' }, async () => {
  const writes = [];
  const inventoryWrites = [];
  for (let i = 0; i < BOT_COUNT; i++) {
    const id = `bot_${String(i + 1).padStart(3, '0')}`;
    const ref = db.collection('players').doc(id);
    const snap = await ref.get();
    const bot = snap.exists ? (snap.data() || {}) : freshBot(i);
    let stars = Math.max(0, Math.min(MAX_STARS, Number(bot.stars) || 100));
    let value = Math.max(0, Math.min(MAX_INVENTORY_VALUE, Number(bot.inventoryStars) || 0));
    let items = Array.isArray(bot.inventoryPreview) ? bot.inventoryPreview.slice(0, 40) : [];
    // Simulated in-game activity: bots earn small rewards and open only their own virtual cases.
    const itemCount = Math.max(0, Number(bot.itemsCount) || 0);
    // Deterministic offline progression: fixed periodic rewards, not paid or chance-based openings.
    stars = Math.min(MAX_STARS, stars + 20 + ((i * 37 + itemCount * 19) % 981));
    const poolIndex = (i + itemCount) % pools.length;
    const pool = pools[poolIndex];
    const gift = pool[(i + itemCount) % pool.length];
    value = Math.min(MAX_INVENTORY_VALUE, value + gift.price);
    items.unshift({ id: gift.id, name: gift.name, icon: gift.icon, price: gift.price, rarity: gift.rarity, unique: false });
    const nextItemCount = itemCount + 1;
    items = items.slice(0, 40);
    const base = snap.exists ? {} : freshBot(i);
    inventoryWrites.push(db.collection('publicInventories').doc(id).collection('items').doc(String(nextItemCount).padStart(12, '0')).set({
      id: gift.id, name: gift.name, icon: gift.icon, price: gift.price, rarity: gift.rarity, unique: false, updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }));
    writes.push(ref.set({
      ...base,
      ownerUid: id,
      playerId: `BOT-${String(i + 1).padStart(3, '0')}`,
      playerIdKey: `BOT-${String(i + 1).padStart(3, '0')}`,
      isBot: true,
      isGuest: false,
      stars,
      inventoryStars: value,
      itemsCount: nextItemCount,
      inventoryPreview: items,
      botRewardSource: 'Периодическая игровая награда',
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true }));
  }
  await Promise.all([...writes, ...inventoryWrites]);
});

// V34 clan operations. All membership and creation changes are performed server-side.
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const CLAN_CREATE_COST = 2_000_000_000_000;
const CLAN_MAX_MEMBERS = 50;
function requireClanAuth(request) {
  if (!request.auth || !request.auth.uid) throw new HttpsError('unauthenticated', 'Войди в аккаунт.');
  return request.auth.uid;
}
function cleanClanName(value) {
  const name = String(value || '').trim().replace(/\s+/g, ' ');
  if (name.length < 3 || name.length > 24 || /[<>\u0000-\u001f]/.test(name)) throw new HttpsError('invalid-argument', 'Название клана: 3–24 символа.');
  return name;
}
exports.createClan = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const name = cleanClanName(request.data?.name);
  const tag = String(request.data?.tag || '').trim().toUpperCase();
  if (!/^[A-Z0-9А-ЯЁ]{2,5}$/.test(tag)) throw new HttpsError('invalid-argument', 'Тег должен содержать 2–5 букв или цифр.');
  const playerRef = db.collection('players').doc(uid);
  const saveRef = db.collection('playerSaves').doc(uid);
  const clanRef = db.collection('clans').doc();
  await db.runTransaction(async (tx) => {
    const [playerSnap, saveSnap] = await Promise.all([tx.get(playerRef), tx.get(saveRef)]);
    if (!playerSnap.exists) throw new HttpsError('failed-precondition', 'Профиль игрока не найден.');
    const player = playerSnap.data() || {};
    if (player.clanId) throw new HttpsError('already-exists', 'Ты уже состоишь в клане.');
    const savedStars = Number(saveSnap.data()?.gameState?.stars);
    const stars = Math.min(Number(player.stars) || 0, Number.isFinite(savedStars) ? savedStars : 0);
    if (stars < CLAN_CREATE_COST) throw new HttpsError('failed-precondition', 'Для создания клана нужно 2 триллиона ⭐.');
    const inventoryStars = Math.max(0, Number(player.inventoryStars) || 0);
    tx.create(clanRef, {
      name, nameLower: name.toLowerCase(), tag, ownerUid: uid,
      memberUids: [uid], memberCount: 1, inventoryStars,
      banner: '', avatar: '', createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    tx.update(playerRef, { stars: stars - CLAN_CREATE_COST, clanId: clanRef.id, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  return { clanId: clanRef.id, name, tag };
});
exports.joinClan = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const clanId = String(request.data?.clanId || '').trim();
  if (!/^[A-Za-z0-9_-]{10,40}$/.test(clanId)) throw new HttpsError('invalid-argument', 'Некорректный ID клана.');
  const playerRef = db.collection('players').doc(uid);
  const clanRef = db.collection('clans').doc(clanId);
  await db.runTransaction(async (tx) => {
    const [playerSnap, clanSnap] = await Promise.all([tx.get(playerRef), tx.get(clanRef)]);
    if (!playerSnap.exists || !clanSnap.exists) throw new HttpsError('not-found', 'Игрок или клан не найден.');
    const player = playerSnap.data() || {}, clan = clanSnap.data() || {};
    if (player.clanId) throw new HttpsError('already-exists', 'Сначала выйди из текущего клана.');
    const members = Array.isArray(clan.memberUids) ? clan.memberUids : [];
    if (members.length >= CLAN_MAX_MEMBERS) throw new HttpsError('resource-exhausted', 'В клане уже 50 участников.');
    if (members.includes(uid)) throw new HttpsError('already-exists', 'Ты уже в этом клане.');
    tx.update(clanRef, { memberUids: admin.firestore.FieldValue.arrayUnion(uid), memberCount: members.length + 1, inventoryStars: Math.max(0, Number(clan.inventoryStars) || 0) + Math.max(0, Number(player.inventoryStars) || 0), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    tx.update(playerRef, { clanId, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  return { clanId };
});
exports.leaveClan = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const playerRef = db.collection('players').doc(uid);
  await db.runTransaction(async (tx) => {
    const playerSnap = await tx.get(playerRef);
    if (!playerSnap.exists || !playerSnap.data()?.clanId) throw new HttpsError('failed-precondition', 'Ты не состоишь в клане.');
    const player = playerSnap.data() || {};
    const clanRef = db.collection('clans').doc(String(player.clanId));
    const clanSnap = await tx.get(clanRef);
    if (!clanSnap.exists) { tx.update(playerRef, { clanId: admin.firestore.FieldValue.delete() }); return; }
    const clan = clanSnap.data() || {}, members = Array.isArray(clan.memberUids) ? clan.memberUids : [];
    if (clan.ownerUid === uid && members.length > 1) throw new HttpsError('failed-precondition', 'Перед выходом передай владение кланом другому участнику.');
    if (members.length <= 1) tx.delete(clanRef);
    else tx.update(clanRef, { memberUids: admin.firestore.FieldValue.arrayRemove(uid), memberCount: members.length - 1, inventoryStars: Math.max(0, (Number(clan.inventoryStars) || 0) - (Number(player.inventoryStars) || 0)), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    tx.update(playerRef, { clanId: admin.firestore.FieldValue.delete(), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  return { ok: true };
});
exports.recalculateClanValue = onDocumentWritten({ document: 'players/{uid}', region: 'europe-west2' }, async (event) => {
  const before = event.data?.before?.data() || {}, after = event.data?.after?.data() || {};
  const clanId = after.clanId || before.clanId;
  if (!clanId) return;
  const clanRef = db.collection('clans').doc(String(clanId));
  const clanSnap = await clanRef.get();
  if (!clanSnap.exists) return;
  const members = Array.isArray(clanSnap.data()?.memberUids) ? clanSnap.data().memberUids : [];
  if (!members.length) return;
  const refs = members.map(id => db.collection('players').doc(id));
  const docs = await db.getAll(...refs);
  const total = docs.reduce((sum, doc) => sum + (doc.exists ? Math.max(0, Number(doc.data()?.inventoryStars) || 0) : 0), 0);
  await clanRef.update({ inventoryStars: total, memberCount: docs.filter(d => d.exists).length, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
});


exports.updateClanAppearance = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const avatar = String(request.data?.avatar || '').trim();
  const banner = String(request.data?.banner || '').trim();
  const validImage = (value) => !value || (/^https:\/\/[^\s"'<>]{1,900}$/i.test(value));
  if (!validImage(avatar) || !validImage(banner)) {
    throw new HttpsError('invalid-argument', 'Укажи корректные HTTPS-ссылки на изображения.');
  }
  const playerSnap = await db.collection('players').doc(uid).get();
  const clanId = String(playerSnap.data()?.clanId || '');
  if (!clanId) throw new HttpsError('failed-precondition', 'Ты не состоишь в клане.');
  const ref = db.collection('clans').doc(clanId);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError('not-found', 'Клан не найден.');
    if (snap.data()?.ownerUid !== uid) throw new HttpsError('permission-denied', 'Менять оформление может только владелец клана.');
    tx.update(ref, { avatar, banner, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  return { ok: true };
});
