const { onSchedule } = require('firebase-functions/v2/scheduler');
const { setGlobalOptions } = require('firebase-functions/v2');
const admin = require('firebase-admin');

admin.initializeApp();
setGlobalOptions({ region: 'europe-west2', maxInstances: 1 });
const db = admin.firestore();
const MAX_STARS = 3_000_000_000_000;
const MAX_INVENTORY_VALUE = 1_000_000_000_000_000_000;
const BOT_COUNT = 40;
const namesA = ['Silent','Neon','Frost','Shadow','Lucky','Crystal','Nova','Pixel','Turbo','Cosmic','Velvet','Dark','Rapid','Solar','Mystic','Zero','Royal','Ghost','Blue','Wild'];
const namesB = ['Fox','Wolf','Star','Raven','Tiger','Comet','Knight','Byte','Dragon','Cat','Orbit','Bear','Spark','Phantom','Ace','Storm','Pearl','Viper','Flame','Echo'];
const avatars = ['🦊','🐺','🐯','🦉','🐼','🐸','🐲','🐱','🦁','🐻','🐨','🦄','🐙','🦋','🐧','🐢','🦅','🐬','🦝','🐹','🐮','🐵','🦖','🐳','🐝','🦩','🦜','🦔','🐺','🐉','🦈','🐰','🐻‍❄️','🦚','🦋','🐌','🦦','🐾','🐣','🦕'];
const pools = [
  [{id:'heart',name:'Сердце',icon:'❤️',price:15,rarity:'Обычный'},{id:'rose',name:'Роза',icon:'🌹',price:25,rarity:'Обычный'},{id:'flowers',name:'Цветы',icon:'💐',price:50,rarity:'Обычный'},{id:'rocket',name:'Ракета',icon:'🚀',price:50,rarity:'Обычный'},{id:'diamond',name:'Алмаз',icon:'💎',price:100,rarity:'Необычный'},{id:'mixedPop',name:'Смешанный поп',icon:'🍬',price:325,rarity:'Редкий'}],
  [{id:'toyBear',name:'Игрушечный медведь',icon:'🧸',price:2500,rarity:'Редкий'},{id:'vinylPlayer',name:'Виниловый проигрыватель',icon:'📀',price:5825,rarity:'Редкий'},{id:'rocket',name:'Ракета',icon:'🚀',price:50,rarity:'Обычный'},{id:'goldBear',name:'Золотой медведь',icon:'🐻',price:25000,rarity:'Эпический'}],
  [{id:'turtlePepeMike',name:'Плюшевый пепе (Майк)',icon:'🐸',price:8825756,rarity:'Эпический'},{id:'turtlePepeDon',name:'Плюшевый пепе (Донателло)',icon:'🐸',price:11937224,rarity:'Эпический'},{id:'turtlePepeRaph',name:'Плюшевый пепе (Рафаэль)',icon:'🐸',price:13537250,rarity:'Эпический'}],
  [{id:'spiderButterfly',name:'Бабочка',icon:'🦋',price:14904562090,rarity:'Эпический'},{id:'spiderWatch',name:'Швейцарские часы',icon:'⌚',price:178506413225,rarity:'Секретный'}]
];
function randomInt(max) { return Math.floor(Math.random() * max); }
function freshBot(i) {
  const nickname = `${pick(namesA)}${pick(namesB)}${10 + randomInt(990)}`;
  return {
    ownerUid: `bot_${String(i + 1).padStart(3, '0')}`,
    playerId: `BOT-${String(i + 1).padStart(3, '0')}`,
    playerIdKey: `BOT-${String(i + 1).padStart(3, '0')}`,
    nickname,
    avatar: avatars[i % avatars.length],
    isBot: true,
    isGuest: false,
    stars: 100,
    inventoryStars: 0,
    itemsCount: 0,
    inventoryPreview: [],
    botInventoryValue: 0,
    botLastCase: 'Бесплатный кейс',
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  };
}
exports.evolveBotAccounts = onSchedule({ schedule: 'every 5 minutes', timeZone: 'Etc/UTC' }, async () => {
  const writes = [];
  const inventoryWrites = [];
  for (let i = 0; i < BOT_COUNT; i++) {
    const id = `bot_${String(i + 1).padStart(3, '0')}`;
    const ref = db.collection('players').doc(id);
    const snap = await ref.get();
    const bot = snap.exists ? (snap.data() || {}) : freshBot(i);
    let stars = Math.max(0, Math.min(MAX_STARS, Number(bot.stars) || 100));
    let value = Math.max(0, Math.min(MAX_INVENTORY_VALUE, Number(bot.inventoryStars) || 0));
    let items = Array.isArray(bot.inventoryPreview) ? bot.inventoryPreview.slice(0, 40) : [];
    // Simulated in-game activity: bots earn small rewards and open only their own virtual cases.
    const itemCount = Math.max(0, Number(bot.itemsCount) || 0);
    // Deterministic offline progression: fixed periodic rewards, not paid or chance-based openings.
    stars = Math.min(MAX_STARS, stars + 20 + ((i * 37 + itemCount * 19) % 981));
    const poolIndex = (i + itemCount) % pools.length;
    const pool = pools[poolIndex];
    const gift = pool[(i + itemCount) % pool.length];
    value = Math.min(MAX_INVENTORY_VALUE, value + gift.price);
    items.unshift({ id: gift.id, name: gift.name, icon: gift.icon, price: gift.price, rarity: gift.rarity, unique: false });
    const nextItemCount = itemCount + 1;
    items = items.slice(0, 40);
    const base = snap.exists ? {} : freshBot(i);
    inventoryWrites.push(db.collection('publicInventories').doc(id).collection('items').doc(String(nextItemCount).padStart(12, '0')).set({
      id: gift.id, name: gift.name, icon: gift.icon, price: gift.price, rarity: gift.rarity, unique: false, updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }));
    writes.push(ref.set({
      ...base,
      ownerUid: id,
      playerId: `BOT-${String(i + 1).padStart(3, '0')}`,
      playerIdKey: `BOT-${String(i + 1).padStart(3, '0')}`,
      isBot: true,
      isGuest: false,
      stars,
      inventoryStars: value,
      itemsCount: nextItemCount,
      inventoryPreview: items,
      botRewardSource: 'Периодическая игровая награда',
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true }));
  }
  await Promise.all([...writes, ...inventoryWrites]);
});

// V34 clan operations. All membership and creation changes are performed server-side.
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const CLAN_CREATE_COST = 500_000_000_000;
const CLAN_MAX_MEMBERS = 50;
function requireClanAuth(request) {
  if (!request.auth || !request.auth.uid) throw new HttpsError('unauthenticated', 'Войди в аккаунт.');
  return request.auth.uid;
}
function cleanClanName(value) {
  const name = String(value || '').trim().replace(/\s+/g, ' ');
  if (name.length < 3 || name.length > 24 || /[<>\u0000-\u001f]/.test(name)) throw new HttpsError('invalid-argument', 'Название клана: 3–24 символа.');
  return name;
}
exports.createClan = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const name = cleanClanName(request.data?.name);
  const tag = String(request.data?.tag || '').trim().toUpperCase();
  if (!/^[A-Z0-9А-ЯЁ]{2,5}$/.test(tag)) throw new HttpsError('invalid-argument', 'Тег должен содержать 2–5 букв или цифр.');
  const playerRef = db.collection('players').doc(uid);
  const saveRef = db.collection('playerSaves').doc(uid);
  const clanRef = db.collection('clans').doc();
  // Repair memberships lost by older clients that replaced the whole players/{uid} document.
  const priorMembership = await db.collection('clans').where('memberUids', 'array-contains', uid).limit(1).get();
  if (!priorMembership.empty) {
    await playerRef.set({ ownerUid: uid, clanId: priorMembership.docs[0].id, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    throw new HttpsError('already-exists', 'Ты уже состоишь в клане. Членство восстановлено — открой вкладку «Кланы» ещё раз.');
  }
  let balanceAfter = null;
  await db.runTransaction(async (tx) => {
    const [playerSnap, saveSnap] = await Promise.all([tx.get(playerRef), tx.get(saveRef)]);
    const player = playerSnap.exists ? (playerSnap.data() || {}) : {};
    const saveData = saveSnap.exists ? (saveSnap.data() || {}) : {};
    const gameState = saveData.gameState && typeof saveData.gameState === 'object' ? saveData.gameState : {};
    if (!playerSnap.exists && !saveSnap.exists) throw new HttpsError('failed-precondition', 'Облачный профиль не найден. Перезайди в аккаунт и дождись синхронизации.');
    // A stale players/{uid}.clanId used to lock players out of clan creation forever.
    // Only a real membership in the referenced clan should block a new clan.
    let linkedClanSnap = null;
    if (player.clanId) linkedClanSnap = await tx.get(db.collection('clans').doc(String(player.clanId)));
    const linkedMembers = linkedClanSnap?.exists && Array.isArray(linkedClanSnap.data()?.memberUids)
      ? linkedClanSnap.data().memberUids : [];
    if (linkedMembers.includes(uid)) throw new HttpsError('already-exists', 'Ты уже состоишь в клане.');
    // The gameState in playerSaves is the canonical full save. The public player document
    // is a leaderboard projection and can lag behind during a sync, so never take the
    // minimum of two copies: that caused valid high balances to be rejected.
    const savedStars = Number(gameState.stars);
    const profileStars = Number(player.stars);
    const stars = Number.isFinite(savedStars) && savedStars >= 0
      ? savedStars
      : (Number.isFinite(profileStars) && profileStars >= 0 ? profileStars : NaN);
    if (!Number.isFinite(stars)) throw new HttpsError('failed-precondition', 'Не удалось прочитать баланс из облачного сохранения. Перезапусти игру и синхронизируй профиль.');
    if (stars < CLAN_CREATE_COST) throw new HttpsError('failed-precondition', `Для создания клана нужно 500 миллиардов ⭐. На сервере сохранено: ${Math.floor(stars)} ⭐.`);
    const inventoryStars = Math.max(0, Number(player.inventoryStars) || 0);
    balanceAfter = stars - CLAN_CREATE_COST;
    const serverTimestamp = admin.firestore.FieldValue.serverTimestamp();
    tx.create(clanRef, {
      name, nameLower: name.toLowerCase(), tag, ownerUid: uid,
      memberUids: [uid], memberCount: 1, inventoryStars,
      banner: '', avatar: '', createdAt: serverTimestamp, updatedAt: serverTimestamp
    });
    tx.set(playerRef, { ownerUid: uid, stars: stars - CLAN_CREATE_COST, clanId: clanRef.id, updatedAt: serverTimestamp }, { merge: true });
    tx.set(saveRef, { ownerUid: uid, gameState: { ...gameState, stars: stars - CLAN_CREATE_COST }, updatedAt: serverTimestamp }, { merge: true });
  });
  return { clanId: clanRef.id, name, tag, chargedStars: CLAN_CREATE_COST, balanceAfter };
});
exports.joinClan = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const clanId = String(request.data?.clanId || '').trim();
  if (!/^[A-Za-z0-9_-]{10,40}$/.test(clanId)) throw new HttpsError('invalid-argument', 'Некорректный ID клана.');
  const playerRef = db.collection('players').doc(uid);
  const clanRef = db.collection('clans').doc(clanId);
  const existingMembership = await db.collection('clans').where('memberUids', 'array-contains', uid).limit(1).get();
  if (!existingMembership.empty) {
    const existingId = existingMembership.docs[0].id;
    await playerRef.set({ ownerUid: uid, clanId: existingId, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    if (existingId === clanId) return { clanId, alreadyMember: true };
    throw new HttpsError('already-exists', 'Ты уже состоишь в другом клане. Членство восстановлено.');
  }
  await db.runTransaction(async (tx) => {
    const [playerSnap, clanSnap] = await Promise.all([tx.get(playerRef), tx.get(clanRef)]);
    if (!playerSnap.exists || !clanSnap.exists) throw new HttpsError('not-found', 'Игрок или клан не найден.');
    const player = playerSnap.data() || {}, clan = clanSnap.data() || {};
    const members = Array.isArray(clan.memberUids) ? clan.memberUids : [];
    if (members.includes(uid)) {
      // Repair the public player pointer if only the clan's member list is correct.
      tx.set(playerRef, { ownerUid: uid, clanId, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      return;
    }
    if (player.clanId) {
      const oldClanSnap = await tx.get(db.collection('clans').doc(String(player.clanId)));
      const oldMembers = oldClanSnap?.exists && Array.isArray(oldClanSnap.data()?.memberUids) ? oldClanSnap.data().memberUids : [];
      if (oldMembers.includes(uid)) throw new HttpsError('already-exists', 'Сначала выйди из текущего клана.');
      // Old clanId was stale (deleted clan / missing member list); joining is safe now.
    }
    if (members.length >= CLAN_MAX_MEMBERS) throw new HttpsError('resource-exhausted', 'В клане уже 50 участников.');
    tx.update(clanRef, { memberUids: admin.firestore.FieldValue.arrayUnion(uid), memberCount: members.length + 1, inventoryStars: Math.max(0, Number(clan.inventoryStars) || 0) + Math.max(0, Number(player.inventoryStars) || 0), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    tx.update(playerRef, { clanId, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  return { clanId };
});

exports.getMyClan = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const playerRef = db.collection('players').doc(uid);
  const playerSnap = await playerRef.get();
  let clanId = String(playerSnap.data()?.clanId || '');
  let clanSnap = clanId ? await db.collection('clans').doc(clanId).get() : null;
  let clanMembers = clanSnap?.exists && Array.isArray(clanSnap.data()?.memberUids) ? clanSnap.data().memberUids : [];
  if (!clanSnap?.exists || !clanMembers.includes(uid)) {
    // Recover membership by the authoritative memberUids array; otherwise clear stale clanId.
    const membership = await db.collection('clans').where('memberUids', 'array-contains', uid).limit(1).get();
    if (membership.empty) {
      if (playerSnap.exists && clanId) await playerRef.set({ clanId: admin.firestore.FieldValue.delete(), updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      return { clan: null, repaired: !!clanId };
    }
    clanSnap = membership.docs[0]; clanId = clanSnap.id;
    await playerRef.set({ ownerUid: uid, clanId, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    clanMembers = Array.isArray(clanSnap.data()?.memberUids) ? clanSnap.data().memberUids : [];
  }
  const clan = clanSnap.data() || {};
  return { clan: { id: clanId, name: clan.name || 'Клан', tag: clan.tag || '', memberCount: Number(clan.memberCount) || clan.memberUids.length, inventoryStars: Number(clan.inventoryStars) || 0, avatar: clan.avatar || '', banner: clan.banner || '', isOwner: clan.ownerUid === uid } };
});
exports.searchClans = onCall({ region: 'europe-west2' }, async (request) => {
  requireClanAuth(request);
  const query = String(request.data?.query || '').trim().replace(/\s+/g, ' ').toLowerCase();
  if (query.length < 2 || query.length > 24) throw new HttpsError('invalid-argument', 'Введи 2–24 символа для поиска.');
  const snap = await db.collection('clans').orderBy('nameLower').startAt(query).endAt(query + '\uf8ff').limit(20).get();
  return { clans: snap.docs.map(doc => { const d = doc.data() || {}; return { id: doc.id, name: d.name || 'Клан', tag: d.tag || '', memberCount: Number(d.memberCount) || 0, inventoryStars: Number(d.inventoryStars) || 0 }; }) };
});

exports.getClanChat = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const playerSnap = await db.collection('players').doc(uid).get();
  const clanId = String(playerSnap.data()?.clanId || '');
  if (!clanId) throw new HttpsError('failed-precondition', 'Сначала вступи в клан.');
  const clanSnap = await db.collection('clans').doc(clanId).get();
  const members = Array.isArray(clanSnap.data()?.memberUids) ? clanSnap.data().memberUids : [];
  if (!clanSnap.exists || !members.includes(uid)) throw new HttpsError('permission-denied', 'Нет доступа к чату этого клана.');
  const snap = await db.collection('clans').doc(clanId).collection('messages').orderBy('createdAt', 'desc').limit(50).get();
  return { messages: snap.docs.map(d => ({ id: d.id, ...d.data(), createdAt: d.data().createdAt?.toMillis?.() || 0 })).reverse() };
});
exports.sendClanChatMessage = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const message = String(request.data?.message || '').trim().slice(0, 300);
  if (!message) throw new HttpsError('invalid-argument', 'Напиши сообщение.');
  const playerSnap = await db.collection('players').doc(uid).get();
  const player = playerSnap.data() || {}, clanId = String(player.clanId || '');
  if (!clanId) throw new HttpsError('failed-precondition', 'Сначала вступи в клан.');
  const clanRef = db.collection('clans').doc(clanId), clanSnap = await clanRef.get();
  const members = Array.isArray(clanSnap.data()?.memberUids) ? clanSnap.data().memberUids : [];
  if (!clanSnap.exists || !members.includes(uid)) throw new HttpsError('permission-denied', 'Нет доступа к чату этого клана.');
  const ref = await clanRef.collection('messages').add({ uid, playerId: String(player.playerId ?? '—'), nickname: String(player.nickname || 'Игрок').slice(0, 24), message, createdAt: admin.firestore.FieldValue.serverTimestamp() });
  return { messageId: ref.id };
});

exports.leaveClan = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const playerRef = db.collection('players').doc(uid);
  await db.runTransaction(async (tx) => {
    const playerSnap = await tx.get(playerRef);
    if (!playerSnap.exists || !playerSnap.data()?.clanId) throw new HttpsError('failed-precondition', 'Ты не состоишь в клане.');
    const player = playerSnap.data() || {};
    const clanRef = db.collection('clans').doc(String(player.clanId));
    const clanSnap = await tx.get(clanRef);
    if (!clanSnap.exists) { tx.update(playerRef, { clanId: admin.firestore.FieldValue.delete() }); return; }
    const clan = clanSnap.data() || {}, members = Array.isArray(clan.memberUids) ? clan.memberUids : [];
    if (!members.includes(uid)) {
      // The profile pointer is stale; clear it without mutating the clan roster.
      tx.update(playerRef, { clanId: admin.firestore.FieldValue.delete(), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
      return;
    }
    if (clan.ownerUid === uid && members.length > 1) throw new HttpsError('failed-precondition', 'Перед выходом передай владение кланом другому участнику.');
    if (members.length <= 1) tx.delete(clanRef);
    else tx.update(clanRef, { memberUids: admin.firestore.FieldValue.arrayRemove(uid), memberCount: members.length - 1, inventoryStars: Math.max(0, (Number(clan.inventoryStars) || 0) - (Number(player.inventoryStars) || 0)), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    tx.update(playerRef, { clanId: admin.firestore.FieldValue.delete(), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  return { ok: true };
});
exports.recalculateClanValue = onDocumentWritten({ document: 'players/{uid}', region: 'europe-west2' }, async (event) => {
  const before = event.data?.before?.data() || {}, after = event.data?.after?.data() || {};
  const clanId = after.clanId || before.clanId;
  if (!clanId) return;
  const clanRef = db.collection('clans').doc(String(clanId));
  const clanSnap = await clanRef.get();
  if (!clanSnap.exists) return;
  const members = Array.isArray(clanSnap.data()?.memberUids) ? clanSnap.data().memberUids : [];
  if (!members.length) return;
  const refs = members.map(id => db.collection('players').doc(id));
  const docs = await db.getAll(...refs);
  const total = docs.reduce((sum, doc) => sum + (doc.exists ? Math.max(0, Number(doc.data()?.inventoryStars) || 0) : 0), 0);
  await clanRef.update({ inventoryStars: total, memberCount: docs.filter(d => d.exists).length, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
});


exports.updateClanAppearance = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const avatar = String(request.data?.avatar || '').trim();
  const banner = String(request.data?.banner || '').trim();
  const validImage = (value) => !value || (/^https:\/\/[^\s"'<>]{1,900}$/i.test(value));
  if (!validImage(avatar) || !validImage(banner)) {
    throw new HttpsError('invalid-argument', 'Укажи корректные HTTPS-ссылки на изображения.');
  }
  const playerSnap = await db.collection('players').doc(uid).get();
  const clanId = String(playerSnap.data()?.clanId || '');
  if (!clanId) throw new HttpsError('failed-precondition', 'Ты не состоишь в клане.');
  const ref = db.collection('clans').doc(clanId);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError('not-found', 'Клан не найден.');
    if (snap.data()?.ownerUid !== uid) throw new HttpsError('permission-denied', 'Менять оформление может только владелец клана.');
    tx.update(ref, { avatar, banner, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  return { ok: true };
});


// V34.7 moderation: reports and bans are written only by trusted callable functions.
async function requireFounder(request) {
  const uid = requireClanAuth(request);
  const metaSnap = await db.collection('system').doc('meta').get();
  const founderUid = metaSnap.exists ? String(metaSnap.data()?.founderUid || '') : '';
  if (!founderUid || founderUid !== uid) {
    throw new HttpsError('permission-denied', 'Сервер не подтвердил владельца ID 0: проверь system/meta/founderUid и войди в тот же Firebase-аккаунт.');
  }
  return uid;
}

// Resolve public numeric game IDs through the canonical reservation map first.
// Older profile documents may be missing playerIdKey, so querying players alone was unreliable.
async function findPlayerByPublicId(targetId) {
  const normalized = String(targetId || '').trim();
  if (!normalized || normalized.length > 32 || !/^\d+$/.test(normalized)) return null;

  const reservation = await db.collection('playerIds').doc(normalized).get();
  const mappedUid = reservation.exists ? String(reservation.data()?.ownerUid || '') : '';
  if (mappedUid) {
    const mappedPlayer = await db.collection('players').doc(mappedUid).get();
    if (mappedPlayer.exists) return mappedPlayer;
  }

  let snap = await db.collection('players').where('playerIdKey', '==', normalized).limit(1).get();
  if (snap.empty) snap = await db.collection('players').where('playerId', '==', normalized).limit(1).get();
  if (snap.empty) snap = await db.collection('players').where('playerId', '==', Number(normalized)).limit(1).get();
  return snap.empty ? null : snap.docs[0];
}

exports.submitPlayerReport = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = requireClanAuth(request);
  const targetId = String(request.data?.targetPlayerId || '').trim();
  const targetUid = String(request.data?.targetUid || '').trim();
  const reason = String(request.data?.reason || '').trim().slice(0, 500);
  if ((!targetId && !targetUid) || reason.length < 5) throw new HttpsError('invalid-argument', 'Укажи игрока и причину жалобы (минимум 5 символов).');
  if (targetUid && targetUid === uid) throw new HttpsError('failed-precondition', 'Нельзя пожаловаться на самого себя.');

  let target = null;
  if (targetUid && targetUid.length <= 128 && !targetUid.includes('/')) {
    const snap = await db.collection('players').doc(targetUid).get();
    if (snap.exists) target = snap;
  }
  if (!target && targetId) target = await findPlayerByPublicId(targetId);
  if (!target?.exists) throw new HttpsError('not-found', 'Игрок не найден. Обнови топ и открой профиль ещё раз.');

  const targetData = target.data() || {};
  const resolvedId = String(targetData.playerId ?? targetId ?? '—');
  if (resolvedId === '0') throw new HttpsError('failed-precondition', 'Нельзя отправить жалобу на основателя через эту форму.');
  if (target.id === uid) throw new HttpsError('failed-precondition', 'Нельзя пожаловаться на самого себя.');

  const ref = db.collection('playerReports').doc();
  await ref.create({
    reporterUid: uid,
    reporterPlayerId: String((await db.collection('players').doc(uid).get()).data()?.playerId ?? '—'),
    targetUid: target.id,
    targetPlayerId: resolvedId,
    targetNickname: String(targetData.nickname || 'Игрок').slice(0, 24),
    reason,
    status: 'open',
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  return { reportId: ref.id };
});

exports.adminSetPlayerBan = onCall({ region: 'europe-west2' }, async (request) => {
  const adminUid = await requireFounder(request);
  const targetId = String(request.data?.targetPlayerId || '').trim();
  const rawDuration = Number(request.data?.durationSeconds);
  const durationSeconds = Number.isFinite(rawDuration) ? Math.max(0, Math.min(315360000, Math.floor(rawDuration))) : 0;
  const reason = String(request.data?.reason || '').trim().slice(0, 500);
  if (!targetId || !reason) throw new HttpsError('invalid-argument', 'Укажи ID игрока и причину блокировки.');
  if (targetId === '0') throw new HttpsError('failed-precondition', 'Нельзя заблокировать ID 0.');
  const targetDoc = await findPlayerByPublicId(targetId);
  if (!targetDoc) throw new HttpsError('not-found', `Игрок с ID ${targetId} не найден в playerIds или players.`);

  const now = Date.now();
  const until = durationSeconds === 0 ? 0 : now + durationSeconds * 1000;
  const historyRef = db.collection('banHistory').doc();
  await db.runTransaction(async (tx) => {
    const current = await tx.get(targetDoc.ref);
    if (!current.exists) throw new HttpsError('not-found', 'Профиль игрока был удалён или перемещён.');
    const currentId = String(current.data()?.playerId ?? targetId);
    if (currentId === '0') throw new HttpsError('failed-precondition', 'Нельзя заблокировать ID 0.');
    tx.set(targetDoc.ref, { ban: { active: true, reason, issuedAt: now, until, issuedBy: adminUid, permanent: durationSeconds === 0 }, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    tx.create(historyRef, { targetUid: targetDoc.id, targetPlayerId: currentId, action: 'ban', reason, issuedAt: now, until, permanent: durationSeconds === 0, issuedBy: adminUid });
  });
  return { ok: true, targetUid: targetDoc.id, targetPlayerId: targetId, until, permanent: durationSeconds === 0 };
});

exports.adminListPlayerReports = onCall({ region: 'europe-west2' }, async (request) => {
  await requireFounder(request);
  const snap = await db.collection('playerReports').orderBy('createdAt', 'desc').limit(50).get();
  const reports = await Promise.all(snap.docs.map(async (doc) => {
    const data = doc.data() || {};
    let targetNickname = String(data.targetNickname || 'Игрок');
    if (data.targetUid && !data.targetNickname) {
      const target = await db.collection('players').doc(String(data.targetUid)).get();
      if (target.exists) targetNickname = String(target.data()?.nickname || 'Игрок').slice(0, 24);
    }
    return { id: doc.id, ...data, targetNickname, createdAt: data.createdAt?.toMillis?.() || 0 };
  }));
  return { reports };
});

exports.adminResolvePlayerReport = onCall({ region: 'europe-west2' }, async (request) => {
  await requireFounder(request);
  const reportId = String(request.data?.reportId || '').trim();
  const status = String(request.data?.status || 'reviewed');
  if (!reportId || !['reviewed', 'dismissed'].includes(status)) throw new HttpsError('invalid-argument', 'Некорректное действие.');
  const ref = db.collection('playerReports').doc(reportId);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError('not-found', 'Жалоба уже удалена или не существует.');
    tx.update(ref, { status, reviewedAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  return { ok: true };
});

exports.adminGrantFounderNft = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = await requireFounder(request);
  const data = request.data || {};
  const itemId = String(data.itemId || '').trim().slice(0, 80);
  const name = String(data.name || '').trim().slice(0, 64);
  const icon = String(data.icon || '🎁').slice(0, 16);
  const price = Math.max(0, Math.min(1_000_000_000_000_000_000, Number(data.price) || 0));
  const rarity = String(data.rarity || 'Обычный').slice(0, 24);
  if (!itemId || !name || !Number.isFinite(price)) throw new HttpsError('invalid-argument', 'Некорректные данные NFT.');
  const saveRef = db.collection('playerSaves').doc(uid), playerRef = db.collection('players').doc(uid);
  let granted;
  await db.runTransaction(async (tx) => {
    const [saveSnap, playerSnap] = await Promise.all([tx.get(saveRef), tx.get(playerRef)]);
    if (!saveSnap.exists) throw new HttpsError('failed-precondition', 'Облачное сохранение ID 0 не найдено.');
    const saveData = saveSnap.data() || {}, gameState = saveData.gameState || {};
    const inventory = Array.isArray(gameState.inventory) ? gameState.inventory.slice() : [];
    if (inventory.length >= 1000) throw new HttpsError('resource-exhausted', 'Инвентарь достиг лимита 1000 NFT.');
    // NFT UIDs in the Android UI are numeric. A string UID made an issued NFT
    // impossible to select in the upgrader and broke inline inventory actions.
    const nextNumericUid = inventory.reduce((max, it) => Math.max(max, Number(it?.uid) || 0), Math.max(1, Number(gameState.nextId) || 1));
    granted = { uid: nextNumericUid, id: itemId, name, icon, price, rarity, unique: false };
    inventory.push(granted);
    const nextState = { ...gameState, inventory, nextId: nextNumericUid + 1 };
    const preview = inventory.slice(-40).map(it => ({ id: String(it.id || ''), name: String(it.name || 'NFT'), icon: String(it.icon || '🎁'), price: Number(it.price) || 0, rarity: String(it.rarity || 'Обычный'), unique: !!it.unique }));
    tx.set(saveRef, { ownerUid: uid, gameState: nextState, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    tx.set(playerRef, { ownerUid: uid, inventoryPreview: preview, inventoryStars: inventory.reduce((sum, it) => sum + Math.max(0, Number(it.price) || 0), 0), itemsCount: inventory.length, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  });
  return { item: granted };
});

exports.adminSetFounderBuffs = onCall({ region: 'europe-west2' }, async (request) => {
  const uid = await requireFounder(request);
  const data = request.data || {};
  const days = Math.max(0, Math.min(3650, Math.floor(Number(data.days) || 0)));
  const hours = Math.max(0, Math.min(23, Math.floor(Number(data.hours) || 0)));
  const minutes = Math.max(0, Math.min(59, Math.floor(Number(data.minutes) || 0)));
  const seconds = Math.max(0, Math.min(59, Math.floor(Number(data.seconds) || 0)));
  const duration = (((days * 24 + hours) * 60 + minutes) * 60 + seconds) * 1000;
  if (duration <= 0) throw new HttpsError('invalid-argument', 'Длительность бафа должна быть больше нуля.');
  const kind = String(data.kind || 'luck');
  if (!['luck', 'cross'].includes(kind)) throw new HttpsError('invalid-argument', 'Неизвестный баф.');
  const patch = kind === 'luck'
    ? { personalLuckMultiplier: [2,4,8,16].includes(Number(data.multiplier)) ? Number(data.multiplier) : 2, personalLuckUntil: Date.now() + duration }
    : { personalSaveChance: Math.max(0, Math.min(100, Number(data.saveChance) || 0)), personalCrossUntil: Date.now() + duration };
  await db.collection('players').doc(uid).set(patch, { merge: true });
  return { ok: true, ...patch };
});
exports.adminUnbanPlayer = onCall({ region: 'europe-west2' }, async (request) => {
  const adminUid = await requireFounder(request);
  const targetId = String(request.data?.targetPlayerId || '').trim();
  if (!targetId || targetId === '0') throw new HttpsError('invalid-argument', 'Укажи корректный ID игрока.');
  const targetDoc = await findPlayerByPublicId(targetId);
  if (!targetDoc) throw new HttpsError('not-found', `Игрок с ID ${targetId} не найден.`);
  const historyRef = db.collection('banHistory').doc();
  const now = Date.now();
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(targetDoc.ref);
    if (!snap.exists) throw new HttpsError('not-found', 'Профиль игрока не найден.');
    tx.set(targetDoc.ref, { ban: { active: false, reason: '', until: 0, permanent: false, removedAt: now, removedBy: adminUid }, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    tx.create(historyRef, { targetUid: targetDoc.id, targetPlayerId: String(snap.data()?.playerId ?? targetId), action: 'unban', issuedAt: now, issuedBy: adminUid });
  });
  return { ok: true, targetUid: targetDoc.id, targetPlayerId: targetId };
});
