from pathlib import Path
import re
root=Path('/mnt/data/work_v3529/NFT_BATTLE_Android_Project')
p=root/'app/src/main/assets/index.html'
s=p.read_text(encoding='utf-8')
assert 'function playRareReveal(item,odds,kind,done,options={})' in s
assert 'const introDuration=5000,introHold=2000' in s
assert 'sceneDuration=15000,rewardDuration=5000' in s
# The current stage already has the requested 5s typewriter + 2s hold + counter + 15s cinematic + 5s prize.
# Make the count feel deliberate and readable; remove animation work from the scene while prize is shown.
css=r'''
<style id="v35-29-cinematic-finish">
/* A polished 2D cinematic language: crisp silhouettes, layered light, restrained particles. */
.rare-cinema-v3525{background:#02030a!important;isolation:isolate;contain:layout paint style!important}
.rare-cinema-v3525 .v3525-backdrop{background:
 radial-gradient(ellipse at 50% 42%,#2b2454 0%,#17132e 27%,#090d1c 58%,#02030a 100%)!important;}
.rare-cinema-v3525 .v3525-nebula{filter:blur(18px)!important;mix-blend-mode:screen;opacity:.12;will-change:opacity}
.rare-cinema-v3525.cinema-ignite .v3525-nebula{opacity:.34}
.rare-cinema-v3525.cinema-storm .v3525-nebula{opacity:.46}
.rare-cinema-v3525.cinema-ascend .v3525-nebula{opacity:.58}
.rare-cinema-v3525 .v3525-camera-wrap{perspective:none!important;transform:none!important}
.rare-cinema-v3525 .v3525-camera{transform:translateY(20px) scale(.92)!important;transform-style:flat!important;filter:none!important;transition:transform 1.1s cubic-bezier(.16,.8,.2,1),opacity .9s ease!important}
.rare-cinema-v3525.cinema-ignite .v3525-camera{transform:translateY(0) scale(1)!important;animation:v3529SceneReveal 1.1s cubic-bezier(.16,.8,.2,1) both!important}
@keyframes v3529SceneReveal{0%{opacity:.15;transform:translateY(20px) scale(.9)}65%{opacity:1;transform:translateY(-3px) scale(1.015)}100%{opacity:1;transform:translateY(0) scale(1)}}
.rare-cinema-v3525 .v3525-ground{transform:none!important;bottom:4%!important;height:23%!important;border-radius:50%!important;background:radial-gradient(ellipse at 50% 45%,#a67cff35 0%,#7253ba12 34%,transparent 70%)!important;box-shadow:0 -8px 36px #9c65ff20!important}
.rare-cinema-v3525 .v3525-ground:after{inset:15% 23%!important;border:1px solid #e2d5ff44!important;box-shadow:0 0 22px #a45cff45,inset 0 0 20px #a45cff25!important}
.rare-cinema-v3525 .v3525-orbit{transform:translate(-50%,-50%)!important;border:1px solid #c9a9ff66!important;box-shadow:0 0 18px #a45cff44!important}
.rare-cinema-v3525.cinema-ignite .v3525-orbit{animation:v3529Orbit 12s linear infinite!important}
@keyframes v3529Orbit{to{rotate:360deg}}
.rare-cinema-v3525 .v3525-rift{transform:translate(-50%,-50%) scale(.35)!important;filter:none!important}
.rare-cinema-v3525.cinema-ignite .v3525-rift{transform:translate(-50%,-50%) scale(1)!important;animation:v3529Rift 2.8s ease-in-out infinite alternate!important}
@keyframes v3529Rift{from{opacity:.48;filter:brightness(.9)}to{opacity:.95;filter:brightness(1.22)}}
.rare-cinema-v3525 .v3525-reaper,.rare-cinema-v3525 .v3525-cube3d,.rare-cinema-v3525 .v3525-clover3d,.rare-cinema-v3525 .v3525-genesis-figure{transform-style:flat!important;filter:drop-shadow(0 12px 20px #000b)!important}
.rare-cinema-v3525 .v3525-cube-particles{perspective:none!important}
.rare-cinema-v3525 .v3525-cube-particles i{box-shadow:0 0 7px currentColor!important;will-change:transform,opacity}
.rare-cinema-v3525.cinema-ignite .v3525-cube-particles i{animation:v3529Spark 3.8s var(--pd) ease-out 1 both!important}
.rare-cinema-v3525.cinema-storm .v3525-cube-particles i{animation-duration:2.9s!important}
@keyframes v3529Spark{0%{opacity:0;transform:translate3d(0,0,0) scale(.35)}12%{opacity:.9}100%{opacity:0;transform:translate3d(calc(var(--px)*1.35),calc(var(--py)*1.2),0) scale(.1)}}
.rare-cinema-v3525 .v3525-starfield{animation:none!important;opacity:.28!important}
.rare-cinema-v3525 .v3525-flash{background:radial-gradient(ellipse at center,#fff 0%,#fffde8 12%,#e6c8ff 25%,transparent 72%)!important}
.rare-cinema-v3525 .v3525-title{letter-spacing:clamp(1px,.65vw,5px)!important;text-shadow:0 0 8px #fff,0 0 22px #bd81ff,0 0 42px #8a5dff!important}
.rare-cinema-v3525 .v3525-tagline{font-weight:900!important;text-shadow:0 0 12px #fff8,0 0 24px #b48aff!important}
/* True Adam: compact white wings and a layered eclipse halo, not oversized feather fans. */
.rare-cinema-v3525.true-adam-cinema .v3525-backdrop{background:
 radial-gradient(ellipse at 50% 43%,#fff0c9 0%,#ffca7330 8%,transparent 24%),
 radial-gradient(ellipse at 50% 50%,#b44b9d35 0%,transparent 42%),
 radial-gradient(ellipse at 50% 52%,#251a39 0%,#090b19 65%,#02030a 100%)!important}
.rare-cinema-v3525.true-adam-cinema .v3525-genesis-wing{width:22%!important;height:16%!important;opacity:0;filter:drop-shadow(0 0 7px #fff9)!important}
.rare-cinema-v3525.true-adam-cinema.cinema-ignite .v3525-genesis-wing{opacity:.72!important}
.rare-cinema-v3525.true-adam-cinema .v3525-title{text-shadow:0 0 10px #fff,0 0 25px #ffdc9a,0 0 44px #e66ac2!important}
/* Black intro and odds counter remain clean, centered, and free of scene layers. */
.rare-cinema-v3525 .v3526-typewriter-screen,.rare-cinema-v3525 .v3526-count-screen{background:#000!important;z-index:120!important}
.rare-cinema-v3525 .v3526-typewriter-text{font-size:clamp(18px,5vw,32px)!important;letter-spacing:clamp(1px,.55vw,4px)!important;text-shadow:0 0 8px #fff,0 0 20px #b9cfff!important}
.rare-cinema-v3525 .v3526-count-number{font-size:clamp(30px,8vw,60px)!important;font-weight:1000!important;font-variant-numeric:tabular-nums!important;text-shadow:0 0 10px #fff,0 0 26px #91bfff,0 0 48px #8e7dff!important}
.rare-cinema-v3525 .v3526-count-track{height:3px!important;background:#ffffff20!important}
.rare-cinema-v3525 .v3526-count-track i{background:linear-gradient(90deg,#8f9dff,#fff,#a7f6ff)!important;box-shadow:0 0 12px #a8dfff!important}
/* Five-second centered NFT reveal: the card is the hero, with a halo and a clean settle. */
.rare-cinema-v3525 .v3525-reward{left:50%!important;top:50%!important;bottom:auto!important;right:auto!important;width:min(76vw,330px)!important;min-height:250px!important;max-height:68vh!important;padding:24px 22px!important;display:flex!important;align-items:center!important;justify-content:center!important;gap:9px!important;border:1px solid #e6d9ff99!important;border-radius:24px!important;background:linear-gradient(155deg,#262344f5,#101326fa 58%,#090b17fa)!important;box-shadow:0 0 0 1px #ffffff12,0 0 28px #a779ff55,0 22px 70px #000d,inset 0 1px #ffffff25!important;backdrop-filter:none!important;opacity:0;transform:translate(-50%,-45%) scale(.82)!important;z-index:45!important}
.rare-cinema-v3525 .v3525-reward:before{content:"";position:absolute;inset:-14px;border-radius:30px;border:1px solid #d8c5ff66;box-shadow:0 0 28px #a56dff44;pointer-events:none;animation:v3529PrizeHalo 2.2s ease-in-out infinite alternate}
.rare-cinema-v3525 .v3525-reward:after{content:"✦";position:absolute;top:12px;right:17px;color:#fff6c8;font-size:22px;text-shadow:0 0 12px #fff,0 0 22px #ffd88a;animation:v3529Twinkle 1.8s ease-in-out infinite alternate}
.rare-cinema-v3525 .v3525-reward .nft-art{width:min(48vw,180px)!important;height:min(30vh,180px)!important;object-fit:contain!important;filter:drop-shadow(0 0 12px #d9b6ff)!important}
.rare-cinema-v3525 .v3525-reward b{font-size:clamp(17px,4vw,23px)!important;text-align:center!important}
.rare-cinema-v3525 .v3525-reward span{font-size:11px!important;text-align:center!important}
.rare-cinema-v3525 .v3525-reward small{font-size:11px!important;text-align:center!important}
.rare-cinema-v3525 .v3525-reward.reward-show{opacity:1!important;transform:translate(-50%,-50%) scale(1)!important;animation:v3529PrizeIn .8s cubic-bezier(.16,.85,.18,1) both!important}
@keyframes v3529PrizeIn{0%{opacity:0;transform:translate(-50%,-44%) scale(.78)}65%{opacity:1;transform:translate(-50%,-51%) scale(1.035)}100%{opacity:1;transform:translate(-50%,-50%) scale(1)}}
@keyframes v3529PrizeHalo{from{opacity:.28;transform:scale(.985)}to{opacity:.9;transform:scale(1.025)}}
@keyframes v3529Twinkle{from{opacity:.35;transform:scale(.8) rotate(-15deg)}to{opacity:1;transform:scale(1.15) rotate(15deg)}}
.rare-cinema-v3525.v3526-prize-finale .v3525-ui{opacity:0!important;transition:opacity .35s ease!important}
.rare-cinema-v3525.v3526-prize-finale .v3525-camera-wrap{opacity:.18;transition:opacity .45s ease}
@media(max-width:700px){
 .rare-cinema-v3525 .v3525-nebula{filter:blur(12px)!important}
 .rare-cinema-v3525 .v3525-cube-particles i{box-shadow:none!important}
 .rare-cinema-v3525 .v3525-reward{width:min(84vw,310px)!important;min-height:220px!important;padding:18px!important}
 .rare-cinema-v3525 .v3525-reward:before{animation:none!important}
 .rare-cinema-v3525 .v3525-reward:after{animation:none!important}
 .rare-cinema-v3525 .v3525-orbit{animation-duration:18s!important}
}
@media(prefers-reduced-motion:reduce){
 .rare-cinema-v3525 *, .rare-cinema-v3525 *:before,.rare-cinema-v3525 *:after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}
}
</style>
'''
s += '\n'+css
p.write_text(s,encoding='utf-8')
# Version metadata
bp=root/'app/build.gradle'
b=bp.read_text(encoding='utf-8')
b=re.sub(r'versionCode\s+\d+', 'versionCode 57', b, count=1)
b=re.sub(r"versionName\s+['\"][^'\"]+['\"]", "versionName '35.29'", b, count=1)
bp.write_text(b,encoding='utf-8')
# README
(root/'README_V35_29_RU.txt').write_text('''NFT BATTLE V35.29 — CINEMATIC FINISH\n\nОснова: V35.28.\n\nСцена апгрейда: 5 секунд печати «NFT БЫЛ АПГРЕЙЖЕН», 2 секунды паузы, расчёт шанса на чёрном экране, затем 15 секунд основной сцены и 5 секунд отдельного центрального показа NFT.\n\nОбновлён визуальный стиль: выразительные 2D-силуэты, слоистое освещение, аккуратные орбиты, компактные крылья TRUE ADAM, центральная карточка награды. Снижена нагрузка от непрерывных частиц и тяжёлых фильтров, добавлен режим reduced motion.\n\nВерсия Android: 35.29, versionCode 57.\n\nВажно: APK и реальные операции Firebase не запускались в этой среде.\n''',encoding='utf-8')
