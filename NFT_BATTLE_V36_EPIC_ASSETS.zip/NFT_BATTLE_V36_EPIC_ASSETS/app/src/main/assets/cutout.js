/* =========================================================
   NFT BATTLE — Epic Cutout Cinema (Roblox-style rarity FX)
   Overrides playRareReveal for upgrade kind.
   Flat 2D cutouts + progressive colored rarity effects.
   ========================================================= */
(function(){
'use strict';

/* ---------- Rarity color palette (Roblox-inspired) ---------- */
const RARITY_COLORS = [
  // tier 0-1  common / uncommon
  { glow:'#9ae6b4', glow2:'#68d391', name:'COMMON',   bg:'#0a1f12' },
  // 2 rare
  { glow:'#63b3ed', glow2:'#4299e1', name:'RARE',     bg:'#0a1628' },
  // 3 epic
  { glow:'#b794f4', glow2:'#9f7aea', name:'EPIC',     bg:'#1a0f2e' },
  // 4 legendary
  { glow:'#f6e05e', glow2:'#ecc94b', name:'LEGENDARY',bg:'#1f1800' },
  // 5 mythic
  { glow:'#fc8181', glow2:'#f56565', name:'MYTHIC',   bg:'#1f0a0a' },
  // 6 ultra
  { glow:'#f687b3', glow2:'#ed64a6', name:'ULTRA',    bg:'#1f0a18' },
  // 7 secret
  { glow:'#fbb6ce', glow2:'#f687b3', name:'SECRET',   bg:'#1a0514' },
  // 8+ infinity
  { glow:'#ffffff', glow2:'#a5f3fc', name:'INFINITY', bg:'#050510' }
];

function tierFromDenom(d){
  d = Number(d) || 1;
  if(d < 50) return 0;
  if(d < 500) return 1;
  if(d < 5000) return 2;
  if(d < 50000) return 3;
  if(d < 5e5) return 4;
  if(d < 5e6) return 5;
  if(d < 5e8) return 6;
  if(d < 5e10) return 7;
  return 8;
}

function colorForDenom(d){
  const t = Math.min(RARITY_COLORS.length-1, tierFromDenom(d));
  return RARITY_COLORS[t];
}

/* ---------- Character roster (original cutouts) ---------- */
const CAST = {
  doc:   { src:'cast/doc.png',   name:'Vortex Professor',  line:'Well, well, well…',   effect:'portal-snap-bomb',   min:1 },
  kid:   { src:'cast/kid.png',   name:'Portal Kid',        line:'Aww geez!',           effect:'fall-gun-yellow',    min:8 },
  axe:   { src:'cast/axe.png',   name:'Axe Walker',        line:'…',                   effect:'wall-swing',        min:50 },
  nox:   { src:'cast/nox.png',   name:'Strategist Nox',    line:'All according to plan',effect:'hand-universe',     min:200 },
  blade: { src:'cast/blade.png', name:'Shadow Blade',      line:'I am atomic.',        effect:'shadow-sword',      min:1000 },
  note:  { src:'cast/note.png',  name:'Chronicler',        line:'I will write your name.', effect:'notebook-black', min:5000 },
  army:  { src:'cast/army.png',  name:'Shadow Commander',  line:'Arise.',              effect:'shadow-army',       min:25000 },
  bloom: { src:'cast/bloom.png', name:'Bloom',             line:'…',                   effect:'kagune-flowers',    min:1e5 },
  puppet:{ src:'cast/puppet.png',name:'Puppeteer',         line:'The strings are cut.', effect:'threads-rift',     min:5e5 },
  sleuth:{ src:'cast/sleuth.png',name:'Detective',         line:'I see it.',           effect:'finger-gun',        min:2e6 }
};

const CAST_ORDER = Object.keys(CAST);

function pickCast(denom){
  // higher denom → higher index character
  let best = CAST_ORDER[0];
  for(const id of CAST_ORDER){
    if(denom >= CAST[id].min) best = id;
  }
  return { id:best, ...CAST[best] };
}

/* ---------- Helpers ---------- */
function later(ms, fn){ return setTimeout(fn, ms); }
function clearLater(id){ clearTimeout(id); }
function fmtOneIn(n){
  n = Math.max(1, Math.floor(Number(n)||1));
  if(n >= 1e15) return (n/1e15).toFixed(1).replace(/\.0$/,'') + 'Qa';
  if(n >= 1e12) return (n/1e12).toFixed(1).replace(/\.0$/,'') + 'T';
  if(n >= 1e9)  return (n/1e9).toFixed(1).replace(/\.0$/,'') + 'B';
  if(n >= 1e6)  return (n/1e6).toFixed(1).replace(/\.0$/,'') + 'M';
  if(n >= 1e3)  return (n/1e3).toFixed(1).replace(/\.0$/,'') + 'K';
  return String(n);
}

function spawnClovers(root, count, color){
  const layer = root.querySelector('.cut-clovers');
  if(!layer) return;
  for(let i=0;i<count;i++){
    const el = document.createElement('span');
    el.className = 'cut-clover';
    el.textContent = '☘';
    el.style.left = (Math.random()*100) + '%';
    el.style.animationDuration = (2.2 + Math.random()*2.5) + 's';
    el.style.animationDelay = (Math.random()*1.2) + 's';
    el.style.fontSize = (14 + Math.random()*14) + 'px';
    el.style.color = color || '#00ff88';
    layer.appendChild(el);
    later(5000, ()=> el.remove());
  }
}

function spawnParticles(root, n, color){
  const layer = root.querySelector('.cut-particles');
  if(!layer) return;
  const cx = 50, cy = 50;
  for(let i=0;i<n;i++){
    const el = document.createElement('span');
    el.className = 'cut-p';
    const angle = Math.random()*Math.PI*2;
    const dist = 80 + Math.random()*180;
    el.style.setProperty('--dx', Math.cos(angle)*dist + 'px');
    el.style.setProperty('--dy', Math.sin(angle)*dist + 'px');
    el.style.left = cx + '%';
    el.style.top = cy + '%';
    el.style.background = color;
    el.style.boxShadow = '0 0 8px ' + color;
    el.style.animationDelay = (Math.random()*0.15) + 's';
    layer.appendChild(el);
    later(1600, ()=> el.remove());
  }
}

/* ---------- Main cinema player ---------- */
let activeCinema = null;
let cinemaTimers = [];

function clearCinemaTimers(){
  cinemaTimers.forEach(clearLater);
  cinemaTimers = [];
}

function playCutoutCinema(item, denom, done, opts={}){
  clearCinemaTimers();
  if(activeCinema){ activeCinema.remove(); activeCinema = null; }

  const col = colorForDenom(denom);
  const cast = pickCast(denom);
  const reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const skipIntro = !!opts.skipIntro;

  const root = document.createElement('div');
  root.className = 'cut-cinema';
  root.dataset.reduced = reduced ? '1' : '0';
  root.style.setProperty('--fx-glow', col.glow);
  root.style.setProperty('--fx-glow2', col.glow2);
  root.style.setProperty('--fx-outline', col.glow);
  root.style.background = col.bg;

  root.innerHTML = `
    <div class="cut-atmos"></div>
    <div class="cut-clovers"></div>
    <div class="cut-lightning" style="display:none"></div>
    <div class="cut-stage">
      <div class="cut-portal" style="display:none"></div>
      <img class="cut-hero" src="${cast.src}" alt="${cast.name}" draggable="false">
      <div class="cut-burst" style="display:none"></div>
      <div class="cut-particles"></div>
    </div>
    <div class="cut-counter" style="display:none">
      <div class="label">${col.name}</div>
      <div class="value">1 IN ${fmtOneIn(denom)}</div>
    </div>
    <div class="cut-card" id="cutCard">
      <div class="nft-art"></div>
      <b></b><span></span>
    </div>
    <div class="cut-intro ${skipIntro?'hidden':''}">
      <div class="cut-intro-text" id="cutIntroText"></div>
    </div>
    <button class="cut-skip" type="button">ПРОПУСТИТЬ</button>
  `;

  document.body.appendChild(root);
  activeCinema = root;

  const hero = root.querySelector('.cut-hero');
  const portal = root.querySelector('.cut-portal');
  const burst = root.querySelector('.cut-burst');
  const lightning = root.querySelector('.cut-lightning');
  const counter = root.querySelector('.cut-counter');
  const intro = root.querySelector('.cut-intro');
  const introText = root.querySelector('#cutIntroText');
  const card = root.querySelector('#cutCard');
  const skipBtn = root.querySelector('.cut-skip');

  // NFT card content
  try{
    if(typeof artMarkup === 'function' && item){
      card.querySelector('.nft-art').innerHTML = artMarkup(item.id, item.icon);
    }
    card.querySelector('b').textContent = (item && item.name) || cast.name;
    card.querySelector('span').textContent = col.name + ' · 1 IN ' + fmtOneIn(denom);
  }catch(e){}

  let finished = false;
  function finish(){
    if(finished) return;
    finished = true;
    clearCinemaTimers();
    root.style.opacity = '0';
    root.style.transition = 'opacity .35s';
    later(380, ()=>{
      root.remove();
      if(activeCinema === root) activeCinema = null;
      if(typeof done === 'function') done();
    });
  }

  skipBtn.onclick = finish;

  // Timeline (seconds feel like Roblox luck reveals)
  const t = (ms, fn) => { const id = later(ms, fn); cinemaTimers.push(id); return id; };

  // 1. Intro text
  if(!skipIntro){
    introText.textContent = cast.line || '…';
    t(900, ()=>{ intro.classList.add('hidden'); });
  } else {
    intro.classList.add('hidden');
  }

  // 2. Portal / entry
  const entryDelay = skipIntro ? 100 : 1100;
  t(entryDelay, ()=>{
    portal.style.display = 'block';
  });

  // 3. Silhouette appears
  t(entryDelay + 700, ()=>{
    hero.classList.add('is-silhouette');
    hero.style.opacity = '0.9';
    hero.style.transform = 'scale(0.85) translateY(10px)';
  });

  // 4. Lightning + clovers for higher tiers
  if(tierFromDenom(denom) >= 3){
    t(entryDelay + 1100, ()=>{
      lightning.style.display = 'block';
      spawnClovers(root, 6 + Math.min(10, Math.floor(Math.log10(denom+1)*2)), col.glow2);
    });
  } else {
    t(entryDelay + 1100, ()=> spawnClovers(root, 6, col.glow));
  }

  // 5. Fill + burst
  t(entryDelay + 1600, ()=>{
    hero.classList.remove('is-silhouette');
    hero.classList.add('is-fill');
    burst.style.display = 'block';
    spawnParticles(root, 8 + Math.min(8, tierFromDenom(denom)), col.glow);
  });

  // 6. Counter appears
  t(entryDelay + 2000, ()=>{
    counter.style.display = 'block';
  });

  // 7. NFT card blink sequence (0.5s on/off) then stay
  t(entryDelay + 2600, ()=>{
    card.classList.add('show');
  });
  t(entryDelay + 3100, ()=>{ card.classList.remove('show'); });
  t(entryDelay + 3600, ()=>{ card.classList.add('show'); });
  t(entryDelay + 4100, ()=>{ card.classList.remove('show'); });
  t(entryDelay + 4600, ()=>{
    card.classList.add('show');
    // final stay
  });

  // 8. Auto close after full sequence
  t(entryDelay + 7800, finish);
}

/* ---------- Override playRareReveal ---------- */
const _origPlayRareReveal = window.playRareReveal;
window.playRareReveal = function(item, odds, kind, done, options={}){
  if(kind !== 'upgrade'){
    if(typeof _origPlayRareReveal === 'function'){
      return _origPlayRareReveal(item, odds, kind, done, options);
    }
    if(typeof done === 'function') done();
    return;
  }
  const chance = Math.max(1e-22, Number(odds)||1e-22);
  const denom = Math.max(1, Math.min(1e24,
    Number(options.luckDenominator) ||
    Number(options.showcaseDenominator) ||
    (100 / chance)
  ));
  playCutoutCinema(item, denom, done, options);
};

/* ---------- Luck multiplier (exact user table) ---------- */
window.getUpgradeLuckMultiplier = function(percent){
  const p = Math.max(0, Number(percent)||0);
  if(p >= 20) return 1;
  if(p >= 15) return 4;            // 15-20% → 4x
  if(p >= 10) return 8;            // 10-15% → 8x
  if(p >= 5)  return 15000;        // 5-10%  → 15k
  if(p >= 3)  return 150000;       // 3-5%   → 150k
  if(p >= 1)  return 1000000;      // 1-3%   → 1M
  if(p >= 0.8) return 25000000;    // 0.8-1% → 25M
  if(p >= 0.6) return 125000000;   // 0.6-0.8% → 125M
  if(p >= 0.4) return 2500000000;  // 0.4-0.6% → 2.5B
  if(p >= 0.2) return 15500000000; // 0.2-0.4% → 15.5B
  if(p >= 0.1) return 125000000000;// 0.1-0.2% → 125B
  return 250000000000;             // <0.1% → 250B cap for review
};

/* ---------- Pointer: 12 o'clock (0°) on 1st + every 10th ---------- */
window.getPointerStopAngle = function(success, percent){
  // Success zone is centered at bottom 180° (6 o'clock). Fail is the rest.
  const chance = Math.max(0, Math.min(100, Number(percent)||0));
  const half = chance * 1.8; // same geometry as the main game
  if(success){
    // small random inside success arc around 180
    return 180 - half + Math.random() * Math.max(0, 2 * half);
  }
  const span = Math.max(0, 360 - 2 * half);
  return 180 + half + Math.random() * span;
};

// Patch runUpgrade isTenth / stopAngle if the original is still present
(function patchRunUpgradePointer(){
  // We can't easily rewrite the whole function, but we can monkey-patch the
  // angle assignment by wrapping the original if it exists.
  // The safest path: override after the original has defined the helpers.
  const origGet = window.getPointerStopAngle;
  // already overridden above
})();

/* ---------- Local clan fallback ---------- */
const LOCAL_CLANS_KEY = 'nft_battle_local_clans_v1';

function loadLocalClans(){
  try{ return JSON.parse(localStorage.getItem(LOCAL_CLANS_KEY)||'{}'); }
  catch(e){ return {}; }
}
function saveLocalClans(data){
  try{ localStorage.setItem(LOCAL_CLANS_KEY, JSON.stringify(data)); }catch(e){}
}

const _origCreateClanUI = window.createClanUI;
window.createClanUI = async function(){
  try{
    if(typeof _origCreateClanUI === 'function'){
      await _origCreateClanUI();
      return;
    }
  }catch(e){
    console.warn('cloud createClan failed, falling back local', e);
  }
  // local fallback
  const name = (document.getElementById('clanNameInput')||{}).value || '';
  const tag  = ((document.getElementById('clanTagInput')||{}).value || '').toUpperCase();
  if(!name || name.length < 2){ if(typeof toast==='function') toast('Введи название клана'); return; }
  if(!tag || tag.length < 2 || tag.length > 5){ if(typeof toast==='function') toast('Тег 2–5 символов'); return; }
  const clans = loadLocalClans();
  if(clans[tag]){ if(typeof toast==='function') toast('Тег уже занят (локально)'); return; }
  // balance check (500B stars)
  const need = 500000000000;
  let stars = 0;
  try{
    if(window.state && Array.isArray(state.inventory)){
      stars = state.inventory.reduce((s,it)=> s + (Number(it.price)||0), 0);
    }
  }catch(e){}
  if(stars < need){
    if(typeof toast==='function') toast('Нужно 500B ⭐ (локальный режим). Сейчас ~' + (stars/1e9).toFixed(1) + 'B');
    return;
  }
  clans[tag] = { name, tag, owner: (window.state&&state.playerId)||'local', members:1, created:Date.now() };
  saveLocalClans(clans);
  if(window.state) state.localClan = clans[tag];
  if(typeof toast==='function') toast('Клан «' + name + '» [' + tag + '] создан (локально)');
  if(typeof loadMyClan === 'function') try{ loadMyClan(); }catch(e){}
  if(typeof renderAll === 'function') try{ renderAll(); }catch(e){}
};

/* ---------- Cinema Gallery ---------- */
window.openCutoutGallery = function(){
  if(document.querySelector('.cut-gallery')) return;
  const g = document.createElement('div');
  g.className = 'cut-gallery';
  g.innerHTML = `
    <h2>🎬 Cinema Gallery</h2>
    <div class="sub">Оригинальные 2D-каты. Эффекты и цвета растут с редкостью (как в Roblox luck-роликах). Все персонажи — оригинальные, не из сериалов.</div>
    <div class="cut-gallery-grid" id="cutGalleryGrid"></div>
    <button class="cut-gallery-close" type="button">ЗАКРЫТЬ</button>
  `;
  document.body.appendChild(g);
  const grid = g.querySelector('#cutGalleryGrid');
  const demos = [
    {d:12, label:'1 IN 12'},
    {d:80, label:'1 IN 80'},
    {d:900, label:'1 IN 900'},
    {d:12000, label:'1 IN 12K'},
    {d:180000, label:'1 IN 180K'},
    {d:2.5e6, label:'1 IN 2.5M'},
    {d:80e6, label:'1 IN 80M'},
    {d:4e9, label:'1 IN 4B'},
    {d:90e9, label:'1 IN 90B'},
    {d:250e9, label:'1 IN 250B'}
  ];
  demos.forEach(demo=>{
    const cast = pickCast(demo.d);
    const col = colorForDenom(demo.d);
    const btn = document.createElement('button');
    btn.className = 'cut-gallery-btn';
    btn.innerHTML = `<img src="${cast.src}" alt=""><b>${cast.name}</b><small style="color:${col.glow}">${demo.label}</small>`;
    btn.onclick = ()=>{
      g.remove();
      playCutoutCinema({name:cast.name, id:cast.id}, demo.d, ()=>{}, {skipIntro:false});
    };
    grid.appendChild(btn);
  });
  g.querySelector('.cut-gallery-close').onclick = ()=> g.remove();
};

/* Inject gallery button near upgrade odds */
function injectGalleryButton(){
  const odds = document.getElementById('upgradeOdds');
  if(!odds || document.getElementById('cutGalleryBtn')) return;
  const btn = document.createElement('button');
  btn.id = 'cutGalleryBtn';
  btn.type = 'button';
  btn.textContent = '🎬 Cinema';
  btn.style.cssText = 'margin-left:8px;padding:4px 10px;border-radius:8px;border:1px solid #7c3aed;background:#1a0a2e;color:#e9d5ff;font-size:12px;font-weight:700;cursor:pointer';
  btn.onclick = openCutoutGallery;
  odds.parentNode.insertBefore(btn, odds.nextSibling);
}

if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', injectGalleryButton);
} else {
  injectGalleryButton();
}
// also try after a short delay in case UI is built later
setTimeout(injectGalleryButton, 1500);
setTimeout(injectGalleryButton, 4000);

window.playCutoutCinema = playCutoutCinema;
window.CUTOUT_CAST = CAST;
window.colorForDenom = colorForDenom;
window.tierFromDenom = tierFromDenom;
window.fmtOneIn = fmtOneIn;

/* Auto compact UI (Roblox-dense) */
(function enableCompact(){
  try {
    document.documentElement.classList.add('compact-ui');
    document.body.classList.add('compact-ui');
  } catch(e){}
})();

console.log('[cutout] Epic Roblox-style rarity cinema ready · compact UI on');
})();
