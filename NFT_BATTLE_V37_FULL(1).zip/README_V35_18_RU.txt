NFT BATTLE V35.18 — CLAN & MODERATION REPAIR
Основа: V35.17_PERFORMANCE_AUDIO_FIX
Android: versionCode 49 / versionName 35.18

Что исправлено в исходниках:
1. Кланы:
   - Создание больше не блокируется одним устаревшим players/{uid}.clanId.
   - Активное членство проверяется по clans/{clanId}.memberUids.
   - Если профиль указывает на удалённый/чужой клан, ссылка clanId очищается/перезаписывается.
   - Вступление проверяет фактический список участников; повторное членство синхронизирует профиль.
   - getMyClan восстанавливает clanId из memberUids или очищает невалидную ссылку.
   - Выход из клана не удаляет/не меняет состав, если профиль содержал устаревшую ссылку.
   - Цена создания остаётся 500 000 000 000 Stars, списание и создание клана выполняются одной Firestore-транзакцией.
2. Жалобы и баны:
   - Поиск по публичному ID сначала разрешается через playerIds/{ID}.ownerUid, затем использует совместимые поля players.
   - Отправка жалобы сохраняет точный Firebase UID, ID отправителя/цели, ник цели и причину.
   - Список/рассмотрение жалоб проверяет подтверждённого владельца и наличие записи.
   - Бан и разбан изменяют профиль и записывают историю в одной транзакции.
   - Онлайн-аккаунт получает экран блокировки сразу через realtime listener.
   - Firestore Rules запрещают клиенту самостоятельно добавлять/снимать поле ban.
3. Существующие аккаунты, ID, Stars, NFT и сохранения не удаляются.

ОБЯЗАТЕЛЬНОЕ РАЗВЁРТЫВАНИЕ СЕРВЕРА
Новый Android APK не обновляет Cloud Functions автоматически. Для активации серверных исправлений нужно развернуть functions/index.js и firestore.rules:

  cd NFT_BATTLE_Android_Project
  cd functions
  npm install
  cd ..
  firebase deploy --only functions,firestore:rules --project nft-battle-v31

Команда выполняется в терминале с установленным Firebase CLI и авторизацией владельца проекта. Cloud Functions требуют включённого биллинга Firebase/Google Cloud. Не помещай пароли или приватные ключи в исходники или ZIP.

Проверка ID 0:
Firebase Console → Firestore Database → system → meta → founderUid должен содержать Firebase Auth UID именно владельца ID 0. Клиентская цифра ID 0 не заменяет серверную проверку UID.

Проверки, выполненные при упаковке:
- Node syntax check: functions/index.js.
- JavaScript syntax check: встроенные script-блоки index.html.
- ZIP integrity test.
- Firebase emulator / реальная Firebase БД не запускались: удалённый сервер не доступен из сборочной среды, поэтому runtime-операции нужно подтвердить после deploy.
