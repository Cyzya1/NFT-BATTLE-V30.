NFT BATTLE V35.25 — см. README_V35_23_RU.txt в корне архива. Firebase Functions: functions/index.js. Android UI: app/src/main/assets/index.html.
