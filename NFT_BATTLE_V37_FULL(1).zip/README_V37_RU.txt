NFT BATTLE V37 FULL
===================
Полный Android-проект (из твоей V35.36) + патчи V37.

ЧТО СОХРАНЕНО ИЗ ОРИГИНАЛА
--------------------------
- Вся структура app/, gradle, Firebase, functions
- Все арт/аудио/настройки
- Стрелка апгрейдера: каждая 10-я + 1-я → ровно 6 часов (180°)
- Luck-таблица
- Кланы, кейсы, инвентарь и т.д.

ЧТО ДОБАВЛЕНО (V37)
-------------------
app/src/main/assets/cutout.css
app/src/main/assets/cutout.js
app/src/main/assets/cast/   — реальные вырезы из твоего видео/фото
  (rick, ayanokoji, dexter, patrick, sung, light, sp_dark, sp_blonde)

В index.html подключены cutout.css + cutout.js (эпичное 2D-кино по редкости).

КАК СОБРАТЬ APK ЧЕРЕЗ GITHUB
----------------------------
1. Залей в корень репозитория файл:  NFT_BATTLE_V37_FULL.zip
2. Залей workflow:  .github/workflows/build-apk-v37.yml
3. Actions → Build NFT BATTLE V37 APK → Run workflow
4. Скачай артефакт NFT-BATTLE-V37-debug.apk

Имя архива в workflow: NFT_BATTLE_V37_FULL.zip
Имя APK: NFT-BATTLE-V37-debug.apk
