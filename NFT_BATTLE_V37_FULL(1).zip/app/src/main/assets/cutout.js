/* =========================================================
   NFT BATTLE V37 ULTIMATE — Epic 2D Cutout Cinema
   Roblox-style progressive rarity FX · smooth FPS · compact UI
   Overrides playRareReveal (upgrade) · pointer 6 o'clock · local clans
   ========================================================= */
(function(){
'use strict';

/* ---------- Rarity palette (colors grow with 1-IN) ---------- */
const RARITY_COLORS = [
  { glow:'#9ae6b4', glow2:'#68d391', name:'COMMON',    bg:'#06140c' }, // 0
  { glow:'#63b3ed', glow2:'#4299e1', name:'RARE',      bg:'#06121f' }, // 1
  { glow:'#b794f4', glow2:'#9f7aea', name:'EPIC',      bg:'#140c24' }, // 2
  { glow:'#f6e05e', glow2:'#ecc94b', name:'LEGENDARY', bg:'#1a1400' }, // 3
  { glow:'#fc8181', glow2:'#f56565', name:'MYTHIC',    bg:'#1a0808' }, // 4
  { glow:'#f687b3', glow2:'#ed64a6', name:'ULTRA',     bg:'#1a0814' }, // 5
  { glow:'#fbb6ce', glow2:'#f687b3', name:'SECRET',    bg:'#160510' }, // 6
  { glow:'#e0f2fe', glow2:'#7dd3fc', name:'IMPOSSIBLE',bg:'#040818' }, // 7
  { glow:'#ffffff', glow2:'#a5f3fc', name:'INFINITY',  bg:'#020208' }  // 8
];

function tierFromDenom(d){
  d = Number(d) || 1;
  if(d < 50) return 0;
  if(d < 500) return 1;
  if(d < 5000) return 2;
  if(d < 50000) return 3;
  if(d < 5e5) return 4;
  if(d < 5e6) return 5;
  if(d < 5e8) return 6;
  if(d < 5e10) return 7;
  return 8;
}

function colorForDenom(d){
  return RARITY_COLORS[Math.min(RARITY_COLORS.length-1, tierFromDenom(d))];
}

function fmtOneIn(d){
  d = Number(d)||1;
  if(d >= 1e12) return (d/1e12).toFixed(1).replace(/\.0$/,'') + 'T';
  if(d >= 1e9)  return (d/1e9).toFixed(1).replace(/\.0$/,'') + 'B';
  if(d >= 1e6)  return (d/1e6).toFixed(1).replace(/\.0$/,'') + 'M';
  if(d >= 1e3)  return (d/1e3).toFixed(1).replace(/\.0$/,'') + 'K';
  return String(Math.round(d));
}

/* ---------- Original 2D cutouts only ---------- */
const CAST = {
  // min = 1-IN threshold when this cast becomes eligible (higher = rarer anim)
  rick:      { id:'rick',      src:'cast/rick.png',      name:'Rick Prime',   line:'Well, well, well…',              effect:'portal-snap',   colors:['#7CFF6B','#1a1a1a','#ffffff'], min:1 },
  ayanokoji: { id:'ayanokoji', src:'cast/ayanokoji.png', name:'Аянакоджи',    line:'Нити уже натянуты.',            effect:'strings',       colors:['#ff3b5c','#ffffff','#111111'], min:50 },
  dexter:    { id:'dexter',    src:'cast/dexter.png',    name:'Декстер',      line:'Time to cut.',                   effect:'wall-swing',    colors:['#ff4d4d','#ffffff','#c0c0c0'], min:200 },
  patrick:   { id:'patrick',   src:'cast/patrick.png',   name:'Патрик Джей',  line:'…',                              effect:'hand-universe', colors:['#ff4fa3','#ffffff','#1a1a1a'], min:1000 },
  sung:      { id:'sung',      src:'cast/sung.png',      name:'Сон Джи Ву',   line:'Arise.',                         effect:'shadow-army',   colors:['#7b5cff','#ff2a2a','#0a0a12'], min:8000 },
  light:     { id:'light',     src:'cast/light.png',     name:'Ягами Лайт',   line:'I will write your name.',        effect:'notebook',      colors:['#111111','#ff2222','#ffffff'], min:50000 },
  sp_dark:   { id:'sp_dark',   src:'cast/sp_dark.png',   name:'SP Dark',      line:'Шкатулка открыта.',              effect:'box-cops',      colors:['#9b59ff','#ffffff','#0d0d0d'], min:250000 },
  sp_blonde: { id:'sp_blonde', src:'cast/sp_blonde.png', name:'SP Blonde',    line:'Южный Парк.',                   effect:'pull-upgrade',  colors:['#ffd84d','#ff7a18','#ffffff'], min:2000000 }
};

function pickCast(denom){
  const list = Object.values(CAST).filter(c => denom >= c.min).sort((a,b)=>b.min-a.min);
  return list[0] || CAST.rick;
}

/* ---------- Helpers ---------- */
function later(ms, fn){
  return setTimeout(fn, ms);
}
function clearLater(id){ clearTimeout(id); }

function spawnClovers(root, n, color){
  const layer = root.querySelector('.cut-clovers');
  if(!layer) return;
  const max = Math.min(n, 14); // hard FPS cap
  for(let i=0;i<max;i++){
    const el = document.createElement('span');
    el.className = 'cut-clover';
    el.textContent = '☘';
    el.style.left = (8 + Math.random()*84) + '%';
    el.style.animationDuration = (2.2 + Math.random()*2.8) + 's';
    el.style.animationDelay = (Math.random()*0.9) + 's';
    el.style.color = color;
    el.style.filter = 'drop-shadow(0 0 6px ' + color + ')';
    layer.appendChild(el);
    later(5200, ()=> el.remove());
  }
}

function spawnParticles(root, n, color){
  const layer = root.querySelector('.cut-particles');
  if(!layer) return;
  const max = Math.min(n, 16); // hard FPS cap
  for(let i=0;i<max;i++){
    const el = document.createElement('span');
    el.className = 'cut-p';
    const angle = Math.random()*Math.PI*2;
    const dist = 70 + Math.random()*200;
    el.style.setProperty('--dx', (Math.cos(angle)*dist) + 'px');
    el.style.setProperty('--dy', (Math.sin(angle)*dist) + 'px');
    el.style.left = '50%';
    el.style.top  = '48%';
    el.style.background = color;
    el.style.boxShadow = '0 0 10px ' + color;
    el.style.animationDelay = (Math.random()*0.12) + 's';
    layer.appendChild(el);
    later(1500, ()=> el.remove());
  }
}

function spawnRings(root, n, color){
  const stage = root.querySelector('.cut-stage');
  if(!stage) return;
  for(let i=0;i<Math.min(n,4);i++){
    const ring = document.createElement('div');
    ring.className = 'cut-ring';
    ring.style.setProperty('--ring-color', color);
    ring.style.animationDelay = (i*0.12) + 's';
    stage.appendChild(ring);
    later(1800, ()=> ring.remove());
  }
}

/* ---------- Main cinema ---------- */
let activeCinema = null;
let cinemaTimers = [];

function clearCinemaTimers(){
  cinemaTimers.forEach(clearLater);
  cinemaTimers = [];
}

function playCutoutCinema(item, denom, done, opts={}){
  clearCinemaTimers();
  if(activeCinema){ activeCinema.remove(); activeCinema = null; }

  const col = colorForDenom(denom);
  const cast = pickCast(denom);
  const tier = tierFromDenom(denom);
  const reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const skipIntro = !!opts.skipIntro;
  // Character-specific palette override
  if(cast.colors && cast.colors.length>=2){
    col.glow = cast.colors[0];
    col.glow2 = cast.colors[1];
    col.bg = 'radial-gradient(ellipse at 50% 40%, '+cast.colors[0]+'33 0%, #05060c 55%, #000 100%)';
  }

  const root = document.createElement('div');
  root.className = 'cut-cinema';
  root.dataset.tier = String(tier);
  root.dataset.effect = cast.effect || 'default';
  root.dataset.cast = cast.id || '';
  root.dataset.reduced = reduced ? '1' : '0';
  root.style.setProperty('--fx-glow', col.glow);
  root.style.setProperty('--fx-glow2', col.glow2);
  root.style.setProperty('--fx-outline', col.glow);
  root.style.background = col.bg;

  root.innerHTML = `
    <div class="cut-atmos"></div>
    <div class="cut-vignette"></div>
    <div class="cut-clovers"></div>
    <div class="cut-lightning" style="display:none"></div>
    <div class="cut-stage">
      <div class="cut-portal" style="display:none"></div>
      <img class="cut-hero" src="${cast.src}" alt="${cast.name}" draggable="false" loading="eager">
      <div class="cut-burst" style="display:none"></div>
      <div class="cut-particles"></div>
    </div>
    <div class="cut-counter" style="display:none">
      <div class="label">${col.name}</div>
      <div class="value">1 IN ${fmtOneIn(denom)}</div>
    </div>
    <div class="cut-card" id="cutCard">
      <div class="nft-art"></div>
      <b></b><span></span>
    </div>
    <div class="cut-intro ${skipIntro?'hidden':''}">
      <div class="cut-intro-text" id="cutIntroText"></div>
    </div>
    <button class="cut-skip" type="button">ПРОПУСТИТЬ</button>
  `;

  document.body.appendChild(root);
  activeCinema = root;

  // Force GPU layer
  root.style.transform = 'translateZ(0)';

  const hero = root.querySelector('.cut-hero');
  const portal = root.querySelector('.cut-portal');
  const burst = root.querySelector('.cut-burst');
  const lightning = root.querySelector('.cut-lightning');
  const counter = root.querySelector('.cut-counter');
  const intro = root.querySelector('.cut-intro');
  const introText = root.querySelector('#cutIntroText');
  const card = root.querySelector('#cutCard');
  const skipBtn = root.querySelector('.cut-skip');

  try{
    if(typeof artMarkup === 'function' && item){
      card.querySelector('.nft-art').innerHTML = artMarkup(item.id, item.icon);
    }
    card.querySelector('b').textContent = (item && item.name) || cast.name;
    card.querySelector('span').textContent = col.name + ' · 1 IN ' + fmtOneIn(denom);
  }catch(e){}

  let finished = false;
  function finish(){
    if(finished) return;
    finished = true;
    clearCinemaTimers();
    root.style.opacity = '0';
    root.style.transition = 'opacity .28s ease';
    later(320, ()=>{
      root.remove();
      if(activeCinema === root) activeCinema = null;
      if(typeof done === 'function') done();
    });
  }
  skipBtn.onclick = finish;

  const t = (ms, fn) => {
    const id = later(ms, fn);
    cinemaTimers.push(id);
    return id;
  };

  // ===== TIMELINE (Roblox-style escalating drama) =====
  // 1. Intro line (character voice)
  if(!skipIntro){
    introText.textContent = cast.line || '…';
    t(1100, ()=> intro.classList.add('hidden'));
  } else {
    intro.classList.add('hidden');
  }
  // Effect tag under counter later
  const effectHints = {
    'portal-snap': 'PORTAL SNAP',
    'strings': 'FATE STRINGS',
    'wall-swing': 'CLEAVE',
    'hand-universe': 'UNIVERSE SHOT',
    'shadow-army': 'ARISE',
    'notebook': 'DEATH NOTE',
    'box-cops': 'PANDORA',
    'pull-upgrade': 'SOUTH PARK'
  };

  const entry = skipIntro ? 80 : 1000;

  // 2. Portal / entry by effect
  t(entry, ()=>{
    portal.style.display = 'block';
    portal.classList.add('open');
    // effect-flavored portal color
    if(cast.effect==='portal-snap') portal.style.boxShadow = '0 0 60px #7CFF6B,0 0 120px #7CFF6B88';
    if(cast.effect==='shadow-army' || cast.effect==='notebook') portal.style.boxShadow = '0 0 60px #7b5cff,0 0 120px #ff2a2a55';
    if(cast.effect==='strings') portal.style.boxShadow = '0 0 60px #ff3b5c,0 0 100px #fff3';
  });

  // 3. Silhouette entry (style depends on character)
  t(entry + 550, ()=>{
    hero.classList.add('is-silhouette');
    hero.style.opacity = '0.92';
    if(cast.effect==='portal-snap'){
      // Rick: from portal center
      hero.style.transform = 'scale(0.55) translateY(40px)';
    } else if(cast.effect==='notebook'){
      // Light: drop from top
      hero.style.transform = 'scale(0.7) translateY(-80px)';
    } else if(cast.effect==='wall-swing'){
      // Dexter: from side
      hero.style.transform = 'scale(0.75) translateX(-60px)';
    } else {
      hero.style.transform = 'scale(0.82) translateY(18px)';
    }
  });

  // 4. Clovers + atmosphere
  t(entry + 900, ()=>{
    const cloverCount = 5 + Math.min(9, Math.floor(Math.log10(denom+1)*1.8));
    spawnClovers(root, cloverCount, tier >= 3 ? col.glow2 : col.glow);
  });

  // 5. Lightning for Epic+
  if(tier >= 3){
    t(entry + 1150, ()=>{
      lightning.style.display = 'block';
      lightning.classList.add('strike');
    });
    if(tier >= 5){
      t(entry + 1450, ()=>{
        lightning.classList.remove('strike');
        void lightning.offsetWidth;
        lightning.classList.add('strike');
      });
    }
  }

  // 6. Color fill + energy rings + particles + effect tag
  t(entry + 1550, ()=>{
    hero.classList.remove('is-silhouette');
    hero.classList.add('is-fill');
    hero.style.transform = 'scale(1) translateY(0)';
    burst.style.display = 'block';
    burst.classList.add('go');
    spawnParticles(root, 7 + Math.min(9, tier), col.glow);
    if(tier >= 2) spawnRings(root, 2 + (tier >= 5 ? 2 : 0), col.glow);
    // effect name flash
    const tag = document.createElement('div');
    tag.className = 'cut-effect-tag';
    tag.textContent = effectHints[cast.effect] || cast.name;
    root.appendChild(tag);
    later(1800, ()=> tag.remove());
  });

  // 7. Screen shake for high tiers
  if(tier >= 4 && !reduced){
    t(entry + 1600, ()=> root.classList.add('shake'));
    t(entry + 2100, ()=> root.classList.remove('shake'));
  }

  // 8. Progressive 1-IN counter (like Roblox luck: climbs then lands)
  // Build intermediate steps that ramp toward final denom
  const steps = [];
  const finals = [denom];
  let cur = Math.max(10, denom / (8 + Math.random()*6));
  for(let i=0;i<5;i++){
    steps.push(Math.max(1, Math.round(cur)));
    cur = cur * (1.6 + Math.random()*1.4);
    if(cur >= denom) break;
  }
  steps.push(denom);

  t(entry + 1800, ()=>{
    counter.style.display = 'block';
    counter.classList.add('punch');
    const valEl = counter.querySelector('.value');
    const labEl = counter.querySelector('.label');
    let si = 0;
    const tick = ()=>{
      if(si >= steps.length || finished) return;
      const d = steps[si++];
      if(valEl) valEl.textContent = '1 IN ' + fmtOneIn(d);
      if(labEl) labEl.textContent = col.name;
      counter.classList.remove('punch');
      void counter.offsetWidth;
      counter.classList.add('punch');
      if(si < steps.length) later(380 + Math.min(200, si*40), tick);
    };
    tick();
  });

  // 9. Big title for high tiers (ETERNAL / SECRET / INFINITY style)
  if(tier >= 5){
    t(entry + 4200, ()=>{
      let title = document.createElement('div');
      title.className = 'cut-big-title';
      title.textContent = tier >= 8 ? 'INFINITY!!' : tier >= 7 ? 'SECRET!!' : tier >= 6 ? 'ETERNAL!!' : 'ULTRA RARE';
      root.appendChild(title);
      later(2800, ()=> title.remove());
    });
  }

  // 10. NFT card blink sequence
  t(entry + 5200, ()=> card.classList.add('show'));
  t(entry + 5600, ()=> card.classList.remove('show'));
  t(entry + 6000, ()=> card.classList.add('show'));
  t(entry + 6400, ()=> card.classList.remove('show'));
  t(entry + 6800, ()=>{
    card.classList.add('show', 'final');
  });

  // 11. Extra pulse for ultra+
  if(tier >= 6){
    t(entry + 7000, ()=>{
      root.classList.add('ultra-pulse');
      spawnParticles(root, 10, col.glow2);
    });
  }

  // 12. Auto-finish
  const total = entry + (tier >= 6 ? 11000 : 9000);
  t(total, finish);
}

/* ---------- Override playRareReveal ---------- */
const _origPlayRareReveal = window.playRareReveal;
window.playRareReveal = function(item, odds, kind, done, options={}){
  // Keep original for case opens if desired; upgrade gets full cinema
  if(kind !== 'upgrade'){
    if(typeof _origPlayRareReveal === 'function'){
      return _origPlayRareReveal(item, odds, kind, done, options);
    }
    if(typeof done === 'function') done();
    return;
  }
  const chance = Math.max(1e-22, Number(odds)||1e-22);
  const denom = Math.max(1, Math.min(1e24,
    Number(options.luckDenominator) ||
    Number(options.showcaseDenominator) ||
    (100 / chance)
  ));
  playCutoutCinema(item, denom, done, options);
};

/* ---------- Exact luck multipliers (user table) ---------- */
window.getUpgradeLuckMultiplier = function(percent){
  const p = Math.max(0, Number(percent)||0);
  // V37 ×4 table
  if(p >= 20) return 1;
  if(p >= 15) return 16;
  if(p >= 10) return 32;
  if(p >= 5)  return 60000;
  if(p >= 3)  return 600000;
  if(p >= 1)  return 4000000;
  if(p >= 0.8) return 100000000;
  if(p >= 0.6) return 500000000;
  if(p >= 0.4) return 10000000000;
  if(p >= 0.2) return 62000000000;
  if(p >= 0.1) return 500000000000;
  return 1000000000000; // 1T
};

/* ---------- Pointer geometry (success centered at 180° = 6 o'clock) ---------- */
window.getPointerStopAngle = function(success, percent){
  const chance = Math.max(0, Math.min(100, Number(percent)||0));
  const half = chance * 1.8;
  if(success){
    return 180 - half + Math.random() * Math.max(0, 2 * half);
  }
  const span = Math.max(0, 360 - 2 * half);
  return 180 + half + Math.random() * span;
};

/* ---------- Local clan fallback ---------- */
const LOCAL_CLANS_KEY = 'nft_battle_local_clans_v1';

function loadLocalClans(){
  try{ return JSON.parse(localStorage.getItem(LOCAL_CLANS_KEY)||'{}'); }
  catch(e){ return {}; }
}
function saveLocalClans(data){
  try{ localStorage.setItem(LOCAL_CLANS_KEY, JSON.stringify(data)); }catch(e){}
}

const _origCreateClanUI = window.createClanUI;
window.createClanUI = async function(){
  try{
    if(typeof _origCreateClanUI === 'function'){
      await _origCreateClanUI();
      return;
    }
  }catch(e){
    console.warn('[cutout] cloud createClan failed, trying local', e);
  }
  // Local fallback
  const name = (document.getElementById('clanNameInput')||{}).value || '';
  const tag  = ((document.getElementById('clanTagInput')||{}).value || '').toUpperCase();
  if(!name.trim() || tag.length < 2){
    if(typeof toast==='function') toast('Введи название и тег (2–5 символов)');
    return;
  }
  const clans = loadLocalClans();
  if(clans[tag]){
    if(typeof toast==='function') toast('Тег уже занят (локально)');
    return;
  }
  const need = 500000000000;
  let stars = 0;
  try{
    if(window.state && Array.isArray(state.inventory)){
      stars = state.inventory.reduce((s,it)=> s + (Number(it.price)||0), 0);
    }
  }catch(e){}
  if(stars < need){
    if(typeof toast==='function') toast('Нужно 500B ⭐ (локальный режим). Сейчас ~' + (stars/1e9).toFixed(1) + 'B');
    return;
  }
  clans[tag] = { name: name.trim(), tag, owner: (window.state&&state.playerId)||'local', members:1, created:Date.now() };
  saveLocalClans(clans);
  if(window.state) state.localClan = clans[tag];
  if(typeof toast==='function') toast('Клан «' + name.trim() + '» [' + tag + '] создан (локально)');
  try{ if(typeof loadMyClan==='function') loadMyClan(); }catch(e){}
  try{ if(typeof renderAll==='function') renderAll(); }catch(e){}
};

/* ---------- Cinema Gallery ---------- */
window.openCutoutGallery = function(){
  if(document.querySelector('.cut-gallery')) return;
  const g = document.createElement('div');
  g.className = 'cut-gallery';
  g.innerHTML = `
    <h2>🎬 Cinema Gallery</h2>
    <div class="sub">Оригинальные 2D-каты. Эффекты и цвета растут с редкостью (Roblox-style). Все персонажи — оригинальные.</div>
    <div class="cut-gallery-grid" id="cutGalleryGrid"></div>
    <button class="cut-gallery-close" type="button">ЗАКРЫТЬ</button>
  `;
  document.body.appendChild(g);
  const grid = g.querySelector('#cutGalleryGrid');
  const demos = [
    {d:12, label:'1 IN 12'},
    {d:80, label:'1 IN 80'},
    {d:900, label:'1 IN 900'},
    {d:12000, label:'1 IN 12K'},
    {d:180000, label:'1 IN 180K'},
    {d:2.5e6, label:'1 IN 2.5M'},
    {d:80e6, label:'1 IN 80M'},
    {d:4e9, label:'1 IN 4B'},
    {d:90e9, label:'1 IN 90B'},
    {d:250e9, label:'1 IN 250B'}
  ];
  demos.forEach(demo=>{
    const cast = pickCast(demo.d);
    const col = colorForDenom(demo.d);
    const btn = document.createElement('button');
    btn.className = 'cut-gallery-btn';
    btn.innerHTML = `<img src="${cast.src}" alt=""><b>${cast.name}</b><small style="color:${col.glow}">${demo.label}</small>`;
    btn.onclick = ()=>{
      g.remove();
      playCutoutCinema({name:cast.name, id:cast.id}, demo.d, ()=>{}, {skipIntro:false});
    };
    grid.appendChild(btn);
  });
  g.querySelector('.cut-gallery-close').onclick = ()=> g.remove();
};

function injectGalleryButton(){
  const odds = document.getElementById('upgradeOdds');
  if(!odds || document.getElementById('cutGalleryBtn')) return;
  const btn = document.createElement('button');
  btn.id = 'cutGalleryBtn';
  btn.type = 'button';
  btn.textContent = '🎬 Cinema';
  btn.style.cssText = 'margin-left:8px;padding:4px 10px;border-radius:8px;border:1px solid #7c3aed;background:#1a0a2e;color:#e9d5ff;font-size:12px;font-weight:700;cursor:pointer';
  btn.onclick = openCutoutGallery;
  odds.parentNode.insertBefore(btn, odds.nextSibling);
}

if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', injectGalleryButton);
} else {
  injectGalleryButton();
}
setTimeout(injectGalleryButton, 1200);
setTimeout(injectGalleryButton, 3500);

window.playCutoutCinema = playCutoutCinema;
window.CUTOUT_CAST = CAST;
window.colorForDenom = colorForDenom;
window.tierFromDenom = tierFromDenom;
window.fmtOneIn = fmtOneIn;

/* Auto compact Roblox-dense UI */
(function enableCompact(){
  try {
    document.documentElement.classList.add('compact-ui');
    document.body.classList.add('compact-ui');
  } catch(e){}
})();

console.log('[cutout V37] Ultimate Roblox-style rarity cinema ready · FPS-capped · compact UI');
})();
