/* =========================================================
   NFT BATTLE V37 ULTIMATE — Epic 2D Cutout Cinema
   Roblox-style progressive rarity FX · smooth FPS · compact UI
   Overrides playRareReveal (upgrade) · pointer 6 o'clock · local clans
   ========================================================= */
(function(){
'use strict';

/* ---------- Rarity palette (colors grow with 1-IN) ---------- */
const RARITY_COLORS = [
  { glow:'#9ae6b4', glow2:'#68d391', name:'COMMON',    bg:'#06140c' }, // 0
  { glow:'#63b3ed', glow2:'#4299e1', name:'RARE',      bg:'#06121f' }, // 1
  { glow:'#b794f4', glow2:'#9f7aea', name:'EPIC',      bg:'#140c24' }, // 2
  { glow:'#f6e05e', glow2:'#ecc94b', name:'LEGENDARY', bg:'#1a1400' }, // 3
  { glow:'#fc8181', glow2:'#f56565', name:'MYTHIC',    bg:'#1a0808' }, // 4
  { glow:'#f687b3', glow2:'#ed64a6', name:'ULTRA',     bg:'#1a0814' }, // 5
  { glow:'#fbb6ce', glow2:'#f687b3', name:'SECRET',    bg:'#160510' }, // 6
  { glow:'#e0f2fe', glow2:'#7dd3fc', name:'IMPOSSIBLE',bg:'#040818' }, // 7
  { glow:'#ffffff', glow2:'#a5f3fc', name:'INFINITY',  bg:'#020208' }  // 8
];

function tierFromDenom(d){
  d = Number(d) || 1;
  if(d < 50) return 0;
  if(d < 500) return 1;
  if(d < 5000) return 2;
  if(d < 50000) return 3;
  if(d < 5e5) return 4;
  if(d < 5e6) return 5;
  if(d < 5e8) return 6;
  if(d < 5e10) return 7;
  return 8;
}

function colorForDenom(d){
  return RARITY_COLORS[Math.min(RARITY_COLORS.length-1, tierFromDenom(d))];
}

function fmtOneIn(d){
  d = Number(d)||1;
  if(d >= 1e12) return (d/1e12).toFixed(1).replace(/\.0$/,'') + 'T';
  if(d >= 1e9)  return (d/1e9).toFixed(1).replace(/\.0$/,'') + 'B';
  if(d >= 1e6)  return (d/1e6).toFixed(1).replace(/\.0$/,'') + 'M';
  if(d >= 1e3)  return (d/1e3).toFixed(1).replace(/\.0$/,'') + 'K';
  return String(Math.round(d));
}

/* ---------- Original 2D cutouts only ---------- */
const CAST = {
  doc:   { id:'doc',   src:'cast/doc.png',   name:'Vortex Professor',  line:'Well, well, well…',        effect:'portal-snap',   min:1 },
  kid:   { id:'kid',   src:'cast/kid.png',   name:'Portal Kid',        line:'Aww geez!',                effect:'fall-gun',      min:8 },
  axe:   { id:'axe',   src:'cast/axe.png',   name:'Axe Walker',        line:'…',                        effect:'wall-swing',    min:50 },
  nox:   { id:'nox',   src:'cast/nox.png',   name:'Strategist Nox',    line:'All according to plan.',   effect:'hand-universe', min:200 },
  blade: { id:'blade', src:'cast/blade.png', name:'Shadow Blade',      line:'I am atomic.',             effect:'shadow-sword',  min:1000 },
  note:  { id:'note',  src:'cast/note.png',  name:'Chronicler',        line:'I will write your name.',  effect:'notebook',      min:5000 },
  army:  { id:'army',  src:'cast/army.png',  name:'Shadow Commander',  line:'Arise.',                   effect:'shadow-army',   min:25000 },
  bloom: { id:'bloom', src:'cast/bloom.png', name:'Bloom',             line:'Grow.',                    effect:'bloom-burst',   min:100000 },
  puppet:{ id:'puppet',src:'cast/puppet.png',name:'Puppet Master',     line:'Dance for me.',            effect:'strings',       min:1e6 },
  sleuth:{ id:'sleuth',src:'cast/sleuth.png',name:'Sleuth',            line:'Case closed.',             effect:'reveal',        min:5e6 }
};

function pickCast(denom){
  const list = Object.values(CAST).filter(c => denom >= c.min).sort((a,b)=>b.min-a.min);
  return list[0] || CAST.doc;
}

/* ---------- Helpers ---------- */
function later(ms, fn){
  return setTimeout(fn, ms);
}
function clearLater(id){ clearTimeout(id); }

function spawnClovers(root, n, color){
  const layer = root.querySelector('.cut-clovers');
  if(!layer) return;
  const max = Math.min(n, 14); // hard FPS cap
  for(let i=0;i<max;i++){
    const el = document.createElement('span');
    el.className = 'cut-clover';
    el.textContent = '☘';
    el.style.left = (8 + Math.random()*84) + '%';
    el.style.animationDuration = (2.2 + Math.random()*2.8) + 's';
    el.style.animationDelay = (Math.random()*0.9) + 's';
    el.style.color = color;
    el.style.filter = 'drop-shadow(0 0 6px ' + color + ')';
    layer.appendChild(el);
    later(5200, ()=> el.remove());
  }
}

function spawnParticles(root, n, color){
  const layer = root.querySelector('.cut-particles');
  if(!layer) return;
  const max = Math.min(n, 16); // hard FPS cap
  for(let i=0;i<max;i++){
    const el = document.createElement('span');
    el.className = 'cut-p';
    const angle = Math.random()*Math.PI*2;
    const dist = 70 + Math.random()*200;
    el.style.setProperty('--dx', (Math.cos(angle)*dist) + 'px');
    el.style.setProperty('--dy', (Math.sin(angle)*dist) + 'px');
    el.style.left = '50%';
    el.style.top  = '48%';
    el.style.background = color;
    el.style.boxShadow = '0 0 10px ' + color;
    el.style.animationDelay = (Math.random()*0.12) + 's';
    layer.appendChild(el);
    later(1500, ()=> el.remove());
  }
}

function spawnRings(root, n, color){
  const stage = root.querySelector('.cut-stage');
  if(!stage) return;
  for(let i=0;i<Math.min(n,4);i++){
    const ring = document.createElement('div');
    ring.className = 'cut-ring';
    ring.style.setProperty('--ring-color', color);
    ring.style.animationDelay = (i*0.12) + 's';
    stage.appendChild(ring);
    later(1800, ()=> ring.remove());
  }
}

/* ---------- Main cinema ---------- */
let activeCinema = null;
let cinemaTimers = [];

function clearCinemaTimers(){
  cinemaTimers.forEach(clearLater);
  cinemaTimers = [];
}

function playCutoutCinema(item, denom, done, opts={}){
  clearCinemaTimers();
  if(activeCinema){ activeCinema.remove(); activeCinema = null; }

  const col = colorForDenom(denom);
  const cast = pickCast(denom);
  const tier = tierFromDenom(denom);
  const reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const skipIntro = !!opts.skipIntro;

  const root = document.createElement('div');
  root.className = 'cut-cinema';
  root.dataset.tier = String(tier);
  root.dataset.reduced = reduced ? '1' : '0';
  root.style.setProperty('--fx-glow', col.glow);
  root.style.setProperty('--fx-glow2', col.glow2);
  root.style.setProperty('--fx-outline', col.glow);
  root.style.background = col.bg;

  root.innerHTML = `
    <div class="cut-atmos"></div>
    <div class="cut-vignette"></div>
    <div class="cut-clovers"></div>
    <div class="cut-lightning" style="display:none"></div>
    <div class="cut-stage">
      <div class="cut-portal" style="display:none"></div>
      <img class="cut-hero" src="${cast.src}" alt="${cast.name}" draggable="false" loading="eager">
      <div class="cut-burst" style="display:none"></div>
      <div class="cut-particles"></div>
    </div>
    <div class="cut-counter" style="display:none">
      <div class="label">${col.name}</div>
      <div class="value">1 IN ${fmtOneIn(denom)}</div>
    </div>
    <div class="cut-card" id="cutCard">
      <div class="nft-art"></div>
      <b></b><span></span>
    </div>
    <div class="cut-intro ${skipIntro?'hidden':''}">
      <div class="cut-intro-text" id="cutIntroText"></div>
    </div>
    <button class="cut-skip" type="button">ПРОПУСТИТЬ</button>
  `;

  document.body.appendChild(root);
  activeCinema = root;

  // Force GPU layer
  root.style.transform = 'translateZ(0)';

  const hero = root.querySelector('.cut-hero');
  const portal = root.querySelector('.cut-portal');
  const burst = root.querySelector('.cut-burst');
  const lightning = root.querySelector('.cut-lightning');
  const counter = root.querySelector('.cut-counter');
  const intro = root.querySelector('.cut-intro');
  const introText = root.querySelector('#cutIntroText');
  const card = root.querySelector('#cutCard');
  const skipBtn = root.querySelector('.cut-skip');

  try{
    if(typeof artMarkup === 'function' && item){
      card.querySelector('.nft-art').innerHTML = artMarkup(item.id, item.icon);
    }
    card.querySelector('b').textContent = (item && item.name) || cast.name;
    card.querySelector('span').textContent = col.name + ' · 1 IN ' + fmtOneIn(denom);
  }catch(e){}

  let finished = false;
  function finish(){
    if(finished) return;
    finished = true;
    clearCinemaTimers();
    root.style.opacity = '0';
    root.style.transition = 'opacity .28s ease';
    later(320, ()=>{
      root.remove();
      if(activeCinema === root) activeCinema = null;
      if(typeof done === 'function') done();
    });
  }
  skipBtn.onclick = finish;

  const t = (ms, fn) => {
    const id = later(ms, fn);
    cinemaTimers.push(id);
    return id;
  };

  // ===== TIMELINE (Roblox-style escalating drama) =====
  // 1. Intro line
  if(!skipIntro){
    introText.textContent = cast.line || '…';
    t(850, ()=> intro.classList.add('hidden'));
  } else {
    intro.classList.add('hidden');
  }

  const entry = skipIntro ? 80 : 1000;

  // 2. Portal opens
  t(entry, ()=>{
    portal.style.display = 'block';
    portal.classList.add('open');
  });

  // 3. Silhouette drops in
  t(entry + 550, ()=>{
    hero.classList.add('is-silhouette');
    hero.style.opacity = '0.92';
    hero.style.transform = 'scale(0.82) translateY(18px)';
  });

  // 4. Clovers + atmosphere
  t(entry + 900, ()=>{
    const cloverCount = 5 + Math.min(9, Math.floor(Math.log10(denom+1)*1.8));
    spawnClovers(root, cloverCount, tier >= 3 ? col.glow2 : col.glow);
  });

  // 5. Lightning for Epic+
  if(tier >= 3){
    t(entry + 1150, ()=>{
      lightning.style.display = 'block';
      lightning.classList.add('strike');
    });
    if(tier >= 5){
      t(entry + 1450, ()=>{
        lightning.classList.remove('strike');
        void lightning.offsetWidth;
        lightning.classList.add('strike');
      });
    }
  }

  // 6. Color fill + energy rings + particles
  t(entry + 1550, ()=>{
    hero.classList.remove('is-silhouette');
    hero.classList.add('is-fill');
    hero.style.transform = 'scale(1) translateY(0)';
    burst.style.display = 'block';
    burst.classList.add('go');
    spawnParticles(root, 7 + Math.min(9, tier), col.glow);
    if(tier >= 2) spawnRings(root, 2 + (tier >= 5 ? 2 : 0), col.glow);
  });

  // 7. Screen shake for high tiers
  if(tier >= 4 && !reduced){
    t(entry + 1600, ()=> root.classList.add('shake'));
    t(entry + 2100, ()=> root.classList.remove('shake'));
  }

  // 8. Counter appears with punch
  t(entry + 1950, ()=>{
    counter.style.display = 'block';
    counter.classList.add('punch');
  });

  // 9. NFT card blink sequence (Roblox-style reveal)
  t(entry + 2500, ()=> card.classList.add('show'));
  t(entry + 2950, ()=> card.classList.remove('show'));
  t(entry + 3400, ()=> card.classList.add('show'));
  t(entry + 3850, ()=> card.classList.remove('show'));
  t(entry + 4300, ()=>{
    card.classList.add('show', 'final');
  });

  // 10. Extra pulse for ultra+
  if(tier >= 6){
    t(entry + 4700, ()=>{
      root.classList.add('ultra-pulse');
      spawnParticles(root, 10, col.glow2);
    });
  }

  // 11. Auto-finish
  const total = entry + (tier >= 6 ? 8200 : 7200);
  t(total, finish);
}

/* ---------- Override playRareReveal ---------- */
const _origPlayRareReveal = window.playRareReveal;
window.playRareReveal = function(item, odds, kind, done, options={}){
  // Keep original for case opens if desired; upgrade gets full cinema
  if(kind !== 'upgrade'){
    if(typeof _origPlayRareReveal === 'function'){
      return _origPlayRareReveal(item, odds, kind, done, options);
    }
    if(typeof done === 'function') done();
    return;
  }
  const chance = Math.max(1e-22, Number(odds)||1e-22);
  const denom = Math.max(1, Math.min(1e24,
    Number(options.luckDenominator) ||
    Number(options.showcaseDenominator) ||
    (100 / chance)
  ));
  playCutoutCinema(item, denom, done, options);
};

/* ---------- Exact luck multipliers (user table) ---------- */
window.getUpgradeLuckMultiplier = function(percent){
  const p = Math.max(0, Number(percent)||0);
  if(p >= 20) return 1;
  if(p >= 15) return 4;
  if(p >= 10) return 8;
  if(p >= 5)  return 15000;
  if(p >= 3)  return 150000;
  if(p >= 1)  return 1000000;
  if(p >= 0.8) return 25000000;
  if(p >= 0.6) return 125000000;
  if(p >= 0.4) return 2500000000;
  if(p >= 0.2) return 15500000000;
  if(p >= 0.1) return 125000000000;
  return 250000000000; // 250B cap
};

/* ---------- Pointer geometry (success centered at 180° = 6 o'clock) ---------- */
window.getPointerStopAngle = function(success, percent){
  const chance = Math.max(0, Math.min(100, Number(percent)||0));
  const half = chance * 1.8;
  if(success){
    return 180 - half + Math.random() * Math.max(0, 2 * half);
  }
  const span = Math.max(0, 360 - 2 * half);
  return 180 + half + Math.random() * span;
};

/* ---------- Local clan fallback ---------- */
const LOCAL_CLANS_KEY = 'nft_battle_local_clans_v1';

function loadLocalClans(){
  try{ return JSON.parse(localStorage.getItem(LOCAL_CLANS_KEY)||'{}'); }
  catch(e){ return {}; }
}
function saveLocalClans(data){
  try{ localStorage.setItem(LOCAL_CLANS_KEY, JSON.stringify(data)); }catch(e){}
}

const _origCreateClanUI = window.createClanUI;
window.createClanUI = async function(){
  try{
    if(typeof _origCreateClanUI === 'function'){
      await _origCreateClanUI();
      return;
    }
  }catch(e){
    console.warn('[cutout] cloud createClan failed, trying local', e);
  }
  // Local fallback
  const name = (document.getElementById('clanNameInput')||{}).value || '';
  const tag  = ((document.getElementById('clanTagInput')||{}).value || '').toUpperCase();
  if(!name.trim() || tag.length < 2){
    if(typeof toast==='function') toast('Введи название и тег (2–5 символов)');
    return;
  }
  const clans = loadLocalClans();
  if(clans[tag]){
    if(typeof toast==='function') toast('Тег уже занят (локально)');
    return;
  }
  const need = 500000000000;
  let stars = 0;
  try{
    if(window.state && Array.isArray(state.inventory)){
      stars = state.inventory.reduce((s,it)=> s + (Number(it.price)||0), 0);
    }
  }catch(e){}
  if(stars < need){
    if(typeof toast==='function') toast('Нужно 500B ⭐ (локальный режим). Сейчас ~' + (stars/1e9).toFixed(1) + 'B');
    return;
  }
  clans[tag] = { name: name.trim(), tag, owner: (window.state&&state.playerId)||'local', members:1, created:Date.now() };
  saveLocalClans(clans);
  if(window.state) state.localClan = clans[tag];
  if(typeof toast==='function') toast('Клан «' + name.trim() + '» [' + tag + '] создан (локально)');
  try{ if(typeof loadMyClan==='function') loadMyClan(); }catch(e){}
  try{ if(typeof renderAll==='function') renderAll(); }catch(e){}
};

/* ---------- Cinema Gallery ---------- */
window.openCutoutGallery = function(){
  if(document.querySelector('.cut-gallery')) return;
  const g = document.createElement('div');
  g.className = 'cut-gallery';
  g.innerHTML = `
    <h2>🎬 Cinema Gallery</h2>
    <div class="sub">Оригинальные 2D-каты. Эффекты и цвета растут с редкостью (Roblox-style). Все персонажи — оригинальные.</div>
    <div class="cut-gallery-grid" id="cutGalleryGrid"></div>
    <button class="cut-gallery-close" type="button">ЗАКРЫТЬ</button>
  `;
  document.body.appendChild(g);
  const grid = g.querySelector('#cutGalleryGrid');
  const demos = [
    {d:12, label:'1 IN 12'},
    {d:80, label:'1 IN 80'},
    {d:900, label:'1 IN 900'},
    {d:12000, label:'1 IN 12K'},
    {d:180000, label:'1 IN 180K'},
    {d:2.5e6, label:'1 IN 2.5M'},
    {d:80e6, label:'1 IN 80M'},
    {d:4e9, label:'1 IN 4B'},
    {d:90e9, label:'1 IN 90B'},
    {d:250e9, label:'1 IN 250B'}
  ];
  demos.forEach(demo=>{
    const cast = pickCast(demo.d);
    const col = colorForDenom(demo.d);
    const btn = document.createElement('button');
    btn.className = 'cut-gallery-btn';
    btn.innerHTML = `<img src="${cast.src}" alt=""><b>${cast.name}</b><small style="color:${col.glow}">${demo.label}</small>`;
    btn.onclick = ()=>{
      g.remove();
      playCutoutCinema({name:cast.name, id:cast.id}, demo.d, ()=>{}, {skipIntro:false});
    };
    grid.appendChild(btn);
  });
  g.querySelector('.cut-gallery-close').onclick = ()=> g.remove();
};

function injectGalleryButton(){
  const odds = document.getElementById('upgradeOdds');
  if(!odds || document.getElementById('cutGalleryBtn')) return;
  const btn = document.createElement('button');
  btn.id = 'cutGalleryBtn';
  btn.type = 'button';
  btn.textContent = '🎬 Cinema';
  btn.style.cssText = 'margin-left:8px;padding:4px 10px;border-radius:8px;border:1px solid #7c3aed;background:#1a0a2e;color:#e9d5ff;font-size:12px;font-weight:700;cursor:pointer';
  btn.onclick = openCutoutGallery;
  odds.parentNode.insertBefore(btn, odds.nextSibling);
}

if(document.readyState === 'loading'){
  document.addEventListener('DOMContentLoaded', injectGalleryButton);
} else {
  injectGalleryButton();
}
setTimeout(injectGalleryButton, 1200);
setTimeout(injectGalleryButton, 3500);

window.playCutoutCinema = playCutoutCinema;
window.CUTOUT_CAST = CAST;
window.colorForDenom = colorForDenom;
window.tierFromDenom = tierFromDenom;
window.fmtOneIn = fmtOneIn;

/* Auto compact Roblox-dense UI */
(function enableCompact(){
  try {
    document.documentElement.classList.add('compact-ui');
    document.body.classList.add('compact-ui');
  } catch(e){}
})();

console.log('[cutout V37] Ultimate Roblox-style rarity cinema ready · FPS-capped · compact UI');
})();
